import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Your implementation of a binary search tree.
 *
 * @author Lauren Fischer
 * @userid lfischer7
 * @GTID 903393056
 * @version 1.0
 */
public class BST<T extends Comparable<? super T>> {
    // DO NOT ADD OR MODIFY INSTANCE VARIABLES.
    private BSTNode<T> root;
    private int size;

    /**
     * A no-argument constructor that should initialize an empty BST.
     *
     * Since instance variables are initialized to their default values, there
     * is no need to do anything for this constructor.
     */
    public BST() {
        // DO NOT IMPLEMENT THIS CONSTRUCTOR!
    }

    /**
     * Initializes the BST with the data in the Collection. The data
     * should be added in the same order it is in the Collection.
     *
     * Hint: Not all Collections are indexable like Lists, so a regular for loop
     * will not work here. However, all Collections are Iterable, so what type
     * of loop would work?
     *
     * @param data the data to add to the tree
     * @throws IllegalArgumentException if data or any element in data is null
     */
    public BST(Collection<T> data) {
        if (data == null) {
            throw new IllegalArgumentException("the collection is empty");
        }
        for (T datum : data) {
            if (datum == null) {
                throw new IllegalArgumentException("cannot add null data");
            }
            add(datum);
        }
    }

    /**
     * Add the data as a leaf in the BST. Should traverse the tree to find the
     * appropriate location. If the data is already in the tree, then nothing
     * should be done (the duplicate shouldn't get added, and size should not be
     * incremented).
     * 
     * Should have a running time of O(log n) for a balanced tree, and a worst
     * case of O(n).
     *
     * @throws IllegalArgumentException if the data is null
     * @param data the data to be added
     */
    public void add(T data) {
        if (data == null) {
            throw new IllegalArgumentException("cannot add null data");
        }
        BSTNode<T> currentNode = root;
        root = addHelper(currentNode, data);
    }

    /**
     * Recursive helper method for add()
     *
     * @param current node the method is currently addressing
     * @param data the data to be added
     * @return returns next node for the method to address
     */

    private BSTNode<T> addHelper(BSTNode<T> current, T data) {
        if (current == null) {
            size++;
            return new BSTNode<T>(data);
        } else if (current.getData().compareTo(data) < 0) {
            current.setRight(addHelper(current.getRight(), data));
            return current;
        } else if (current.getData().compareTo(data) > 0) {
            current.setLeft(addHelper(current.getLeft(), data));
            return current;
        } else {
            return current;
        }
    }


    /**
     * Removes the data from the tree. There are 3 cases to consider:
     *
     * 1: the data is a leaf (no children). In this case, simply remove it.
     * 2: the data has one child. In this case, simply replace it with its
     * child.
     * 3: the data has 2 children. Use the predecessor to replace the data.
     * You MUST use recursion to find and remove the predecessor (you will
     * likely need an additional helper method to handle this case efficiently).
     *
     * Should have a running time of O(log n) for a balanced tree, and a worst
     * case of O(n).
     *
     * @throws IllegalArgumentException if the data is null
     * @throws java.util.NoSuchElementException if the data is not found
     * @param data the data to remove from the tree.
     * @return the data removed from the tree. Do not return the same data
     * that was passed in. Return the data that was stored in the tree.
     */
    public T remove(T data) {
        if (data == null) {
            throw new IllegalArgumentException("cannot remove null data");
        }
        BSTNode<T> tempNode = new BSTNode<T>(data);
        root = removeHelper(root, data, tempNode);
        size--;
        return tempNode.getData();
    }
    /**
     * Recursive helper method for remove()
     *
     * @throws java.util.NoSuchElementException if the data is not found
     * @param curr the node the method is currently addressing
     * @param data the data to remove from the tree.
     * @param temp dummy node to store data removed from the tree
     * @return returns the next node for the method to address
     */
    private BSTNode<T> removeHelper(BSTNode<T> curr, T data, BSTNode<T> temp) {
        if (curr == null) {
            throw new NoSuchElementException(
                    "could not find element to remove");
        }
        if (curr.getData().equals(data)) {
            if (curr.getRight() == null && curr.getLeft() == null) {
                temp.setData(curr.getData());
                return null;
            } else if ((curr.getRight() != null && curr.getLeft() == null)) {
                temp.setData(curr.getData());
                return curr.getRight();
            } else if ((curr.getLeft() != null && curr.getRight() == null)) {
                temp.setData(curr.getData());
                return curr.getLeft();
            } else {
                temp.setData(curr.getData());
                BSTNode<T> temp2 = new BSTNode<T>(data);
                curr.setLeft(predecessor(curr.getLeft(), temp2));
                curr.setData(temp2.getData());
            }
        } else if (data.compareTo(curr.getData()) < 0) {
            curr.setLeft(removeHelper(curr.getLeft(), data, temp));
        } else if (data.compareTo(curr.getData()) > 0) {
            curr.setRight(removeHelper(curr.getRight(), data, temp));
        }
        return curr;
    }

    /**
     * method to find the predecessor
     *
     * @param curr the node the method is currently addressing
     * @param temp2 dummy node to store the predecessor
     * @return returns the new current node
     */
    private BSTNode<T> predecessor(BSTNode<T> curr, BSTNode<T> temp2) {
        if (curr.getRight() == null) {
            temp2.setData(curr.getData());
            return curr.getLeft();
        } else {
            curr.setRight(predecessor(curr.getRight(), temp2));
        }
        return curr;
    }

    /**
     * Returns the data in the tree matching the parameter passed in (think
     * carefully: should you use value equality or reference equality?).
     *
     * Should have a running time of O(log n) for a balanced tree, and a worst
     * case of O(n).
     *
     * @throws IllegalArgumentException if the data is null
     * @throws java.util.NoSuchElementException if the data i
     * s not found
     * @param data the data to search for in the tree.
     * @return the data in the tree equal to the parameter. Do not return the
     * same data that was passed in.  Return the data that was stored in the
     * tree.
     */
    public T get(T data) {
        if (data == null) {
            throw new IllegalArgumentException("cannot get null data");
        }
        BSTNode<T> currentNode = root;
        return getHelper(root, data).getData();
    }

    /**
     * Recursive helper method for get()
     *
     * @throws java.util.NoSuchElementException if the data i
     * s not found
     * @param current the node the method is currently addressing
     * @param data the data to search for in the tree.
     * @return returns the node with the data being searched for
     */

    private BSTNode<T> getHelper(BSTNode<T> current, T data) {
        if (current == null) {
            throw new NoSuchElementException("data could not be found");
        }
        if (current.getData().equals(data)) {
            return current;
        } else if (current.getData().compareTo(data) < 0) {
            return getHelper(current.getRight(), data);
        } else {
            return getHelper(current.getLeft(), data);
        }
    }

    /**
     * Returns whether or not data equivalent to the given parameter is
     * contained within the tree. The same type of equality should be used as
     * in the get method.
     *
     * Should have a running time of O(log n) for a balanced tree, and a worst
     * case of O(n).
     *
     * @throws IllegalArgumentException if the data is null
     * @param data the data to search for in the tree.
     * @return whether or not the parameter is contained within the tree.
     */
    public boolean contains(T data) {
        if (data == null) {
            throw new IllegalArgumentException("cannot search for null data");
        }
        return containsHelper(root, data);
    }

    /**
     * Recursive helper method for contains()
     *
     * @param current the node the method is currently addressing
     * @param data the data to search for in the tree
     * @return whether or not the parameter is contained within the tree.
     */

    private boolean containsHelper(BSTNode<T> current, T data) {
        if (current == null) {
            return false;
        }
        if (current.getData().equals(data)) {
            return true;
        } else if (current.getData().compareTo(data) < 0) {
            return containsHelper(current.getRight(), data);
        } else {
            return containsHelper(current.getLeft(), data);
        }
    }

    /**
     * Should run in O(n).
     *
     * @return a preorder traversal of the tree
     */
    public List<T> preorder() {
        List<T> preord = new ArrayList<T>();
        preHelper(root, preord);
        return preord;
    }

    /**
     * Recursive helper method for preorder()
     *
     * @param curr the node the method is currently addressing
     * @param list the list the nodes are added to in preorder
     */
    private void preHelper(BSTNode<T> curr, List<T> list) {
        if (curr == null) {
            return;
        }
        list.add(curr.getData());
        preHelper(curr.getLeft(), list);
        preHelper(curr.getRight(), list);
    }

    /**
     * Should run in O(n).
     *
     * @return an inorder traversal of the tree
     */
    public List<T> inorder() {
        List<T> inord = new ArrayList<T>();
        inHelper(root, inord);
        return inord;
    }

    /**
     * Recursive helper method for inorder()
     *
     * @param curr the node the method is currently addressing
     * @param list the list the nodes are added to in inorder
     */

    private void inHelper(BSTNode<T> curr, List<T> list) {
        if (curr == null) {
            return;
        }
        inHelper(curr.getLeft(), list);
        list.add(curr.getData());
        inHelper(curr.getRight(), list);
    }
    /**
     * Should run in O(n).
     *
     * @return a postorder traversal of the tree
     */
    public List<T> postorder() {
        List<T> postord = new ArrayList<T>();
        postHelper(root, postord);
        return postord;
    }

    /**
     * Recursive helper method for postorder()
     *
     * @param curr the node the method is currently addressing
     * @param list the list the nodes are added to in postorder
     */

    private void postHelper(BSTNode<T> curr, List<T> list) {
        if (curr == null) {
            return;
        }
        postHelper(curr.getLeft(), list);
        postHelper(curr.getRight(), list);
        list.add(curr.getData());
    }
    /**
     * Generate a level-order traversal of the tree.
     *
     * To do this, add the root node to a queue. Then, while the queue isn't
     * empty, remove one node, add its data to the list being returned, and add
     * its left and right child nodes to the queue. If what you just removed is
     * {@code null}, ignore it and continue with the rest of the nodes.
     *
     * Should run in O(n). This does not need to be done recursively.
     *
     * @return a level order traversal of the tree
     */
    public List<T> levelorder() {
        List<T> lvlord = new ArrayList<T>();
        Queue<BSTNode<T>> levelQueue = new LinkedList<BSTNode<T>>();
        BSTNode<T> currentNode = root;
        levelQueue.add(currentNode);
        while (!levelQueue.isEmpty() && root != null) {
            currentNode = levelQueue.remove();
            lvlord.add(currentNode.getData());
            if (currentNode.getLeft() != null) {
                levelQueue.add(currentNode.getLeft());
            }
            if (currentNode.getRight() != null) {
                levelQueue.add(currentNode.getRight());
            }
        }
        return lvlord;
    }

    /**
     * This method checks whether a binary tree meets the criteria for being
     * a binary search tree.
     *
     * This method is a static method that takes in a BSTNode called
     * {@code treeRoot}, which is the root of the tree that you should check.
     *
     * You may assume that the tree passed in is a proper binary tree; that is,
     * there are no loops in the tree, the parent-child relationship is
     * correct, that there are no duplicates, and that every parent has at
     * most 2 children. So, what you will have to check is that the order
     * property of a BST is still satisfied.
     *
     * Should run in O(n). However, you should stop the check as soon as you
     * find evidence that the tree is not a BST rather than checking the rest
     * of the tree.
     *
     * @param <T> the generic typing
     * @param treeRoot the root of the binary tree to check
     * @return true if the binary tree is a BST, false otherwise
     */
    public static <T extends Comparable<? super T>> boolean isBST(
            BSTNode<T> treeRoot) {
        return isBSTHelper(null, null, treeRoot);
    }

    /**
     * Recursive helper method for isBST()
     *
     * @param <T> the generic typing
     * @param lowerBound the lower boundary for the node's value
     * @param upperBound the upper boundary for the node's value
     * @param curr the node currently being evaluated
     * @return true if the binary tree is a BST, false otherwise
     */
    private static <T extends Comparable<? super T>>
        boolean isBSTHelper(T lowerBound, T upperBound, BSTNode<T> curr) {
        if (curr == null) {
            return true;
        }
        if ((lowerBound == null || lowerBound.compareTo(curr.getData()) < 0)
                && (upperBound == null
                || upperBound.compareTo(curr.getData()) > 0)) {
            return (isBSTHelper(lowerBound, curr.getData(), curr.getLeft())
                    && isBSTHelper(curr.getData(), upperBound,
                    curr.getRight()));
        } else {
            return false;
        }
    }

    /**
     * Clears the tree.
     *
     * Should run in O(1).
     */
    public void clear() {
        root = null;
        size = 0;
    }

    /**
     * Calculate and return the height of the root of the tree. A node's
     * height is defined as {@code max(left.height, right.height) + 1}. A leaf
     * node has a height of 0 and a null child should be -1.
     *
     * Should be calculated in O(n).
     *
     * @return the height of the root of the tree, -1 if the tree is empty
     */
    public int height() {
        return heightHelper(root);
    }

    /**
     * Recursive helper method for height()
     *
     * @param current the node the method is currently addressing
     * @return the height of the root of the tree, -1 if the tree is empty
     */

    public int heightHelper(BSTNode<T> current) {
        if (current == null) {
            return -1;
        }
        int leftHeight = heightHelper(current.getLeft());
        int rightHeight = heightHelper(current.getRight());
        if (rightHeight > leftHeight) {
            return rightHeight + 1;
        } else {
            return leftHeight + 1;
        }
    }

    /**
     * Returns the size of the BST.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the number of elements in the tree
     */
    public int size() {
        // DO NOT MODIFY THIS METHOD!
        return size;
    }

    /**
     * Returns the root of the BST.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the root of the tree
     */
    public BST<T> getRoot() {
        // DO NOT MODIFY THIS METHOD!
        return root;
    }
}