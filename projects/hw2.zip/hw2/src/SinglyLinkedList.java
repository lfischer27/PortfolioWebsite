/**
 * Your implementation of a circular singly linked list.
 *
 * @author Lauren Fischer
 * @userid lfischer7
 * @GTID 903393056
 * @version 1.0
 */
public class SinglyLinkedList<T> {
    // Do not add new instance variables or modify existing ones.
    private LinkedListNode<T> head;
    private int size;

    /**
     * Adds the element to the index specified.
     *
     * Adding to indices 0 and {@code size} should be O(1), all other cases are
     * O(n).
     *
     * @param index the requested index for the new element
     * @param data the data for the new element
     * @throws java.lang.IndexOutOfBoundsException if index is negative or
     * index > size
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addAtIndex(int index, T data) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException(
                    "index is negative or greater than size");
        }
        if (data == null) {
            throw new IllegalArgumentException("cannot add null data");
        }
        if (head == null && index == 0) {
            LinkedListNode<T> newNode = new LinkedListNode(data, head);
            head = newNode;
            head.setNext(head);
            size++;
        } else if (index == 0) {
            LinkedListNode<T> newNode =
                    new LinkedListNode(data, head.getNext());
            head.setNext(newNode);
            newNode.setData(head.getData());
            head.setData(data);
            size++;
        } else if (index == size) {
            addToBack(data);
        } else {
            LinkedListNode<T> currentNode = head;
            for (int i = 0; i < index - 1; i++) {
                currentNode = currentNode.getNext();
            }
            LinkedListNode<T> newNode =
                    new LinkedListNode(data, currentNode.getNext());
            currentNode.setNext(newNode);
            size++;
        }

    }

    /**
     * Adds the element to the front of the list.
     *
     * Must be O(1) for all cases.
     *
     * @param data the data for the new element
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToFront(T data) {
        if (data == null) {
            throw new IllegalArgumentException("cannot add null data");
        }
        if (head == null) {
            LinkedListNode<T> newNode = new LinkedListNode(data, head);
            head = newNode;
            head.setNext(head);
            size++;
        } else {
            LinkedListNode<T> newNode =
                    new LinkedListNode(data, head.getNext());
            head.setNext(newNode);
            newNode.setData(head.getData());
            head.setData(data);
            size++;
        }
    }

    /**
     * Adds the element to the back of the list.
     *
     * Must be O(1) for all cases.
     *
     * @param data the data for the new element
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToBack(T data) {
        if (data == null) {
            throw new IllegalArgumentException("cannot add null data");
        }
        if (head == null) {
            LinkedListNode<T> newNode = new LinkedListNode(data, head);
            head = newNode;
            head.setNext(head);
            size++;
        } else {
            LinkedListNode<T> newNode =
                    new LinkedListNode(data, head.getNext());
            head.setNext(newNode);
            newNode.setData(head.getData());
            head.setData(data);
            head = newNode;
            size++;
        }
    }

    /**
     * Removes and returns the element from the index specified.
     *
     * Removing from index 0 should be O(1), all other cases are O(n).
     *
     * @param index the requested index to be removed
     * @return the data formerly located at index
     * @throws java.lang.IndexOutOfBoundsException if index is negative or
     * index >= size
     */
    public T removeAtIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(
                    "index is either negative or greater"
                            + " than or equal to size");
        }
        if (size == 1) {
            T data = head.getData();
            head = null;
            size--;
            return data;
        }
        if (index == 0) {
            T data = head.getData();
            head.setData(head.getNext().getData());
            head.setNext(head.getNext().getNext());
            size--;
            return data;
        } else {
            LinkedListNode<T> currentNode = head;
            for (int i = 0; i < index - 1; i++) {
                currentNode = currentNode.getNext();
            }
            T data = currentNode.getNext().getData();
            currentNode.setNext(currentNode.getNext().getNext());
            size--;
            return data;
        }
    }

    /**
     * Removes and returns the element at the front of the list. If the list is
     * empty, return {@code null}.
     *
     * Must be O(1) for all cases.
     *
     * @return the data formerly located at the front, null if empty list
     */
    public T removeFromFront() {
        if (size == 0) {
            return null;
        } else if (size == 1) {
            T data = head.getData();
            head = null;
            size--;
            return data;
        } else {
            T data = head.getData();
            head.setData(head.getNext().getData());
            head.setNext(head.getNext().getNext());
            size--;
            return data;
        }
    }

    /**
     * Removes and returns the element at the back of the list. If the list is
     * empty, return {@code null}.
     *
     * Must be O(n) for all cases.
     *
     * @return the data formerly located at the back, null if empty list
     */
    public T removeFromBack() {
        if (size == 0) {
            return null;
        }
        if (size == 1) {
            T data = head.getData();
            size--;
            head = null;
            return data;
        }
        if (size == 2) {
            T data = head.getNext().getData();
            head.setNext(head);
            size--;
            return data;
        }
        LinkedListNode<T> currentNode = head;
        while (currentNode.getNext().getNext() != head) {
            currentNode = currentNode.getNext();
        }
        T data = currentNode.getNext().getData();
        currentNode.setNext(head);
        size--;
        return data;
    }

    /**
     * Removes the last copy of the given data from the list.
     *
     * Must be O(n) for all cases.
     *
     * @param data the data to be removed from the list
     * @return the removed data occurrence from the list itself (not the data
     * passed in), null if no occurrence
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public T removeLastOccurrence(T data) {
        if (data == null) {
            throw new IllegalArgumentException("data provided is null");
        }
        if (size == 0) {
            return null;
        }

        T dataFromLL = null;
        LinkedListNode<T> currentNode1 = null;
        LinkedListNode<T> currentNode2 = head;
        if (head.getData().equals(data)) {
            currentNode1 = head;
        }
        while (currentNode2.getNext() != head) {
            if (currentNode2.getNext().getData().equals(data)) {
                currentNode1 = currentNode2;
            }
            currentNode2 = currentNode2.getNext();
        }
        if (currentNode1 == null) {
            return null;
        } else if (currentNode1 == head && size == 1) {
            dataFromLL = head.getData();
            head = null;
            size--;
            return dataFromLL;
        } else if (currentNode1 == head
                && !head.getNext().getData().equals(data)) {
            dataFromLL = head.getData();
            head.setData(head.getNext().getData());
            head.setNext(head.getNext().getNext());
            size--;
            return dataFromLL;
        } else {
            dataFromLL = currentNode1.getNext().getData();
            currentNode1.setNext(currentNode1.getNext().getNext());
            size--;
            return dataFromLL;
        }
    }

    /**
     * Returns the element at the specified index.
     *
     * Getting index 0 should be O(1), all other cases are O(n).
     *
     * @param index the index of the requested element
     * @return the object stored at index
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or
     * index >= size
     */
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(
                    "index is negative or greater than or equal to size");
        }
        if (index == 0) {
            return head.getData();
        } else {
            LinkedListNode<T> currentNode = head;
            for (int i = 0; i < index; i++) {
                currentNode = currentNode.getNext();
            }
            return currentNode.getData();
        }
    }

    /**
     * Returns an array representation of the linked list.
     *
     * Must be O(n) for all cases.
     *
     * @return an array of length {@code size} holding all of the objects in
     * this list in the same order
     */
    public Object[] toArray() {
        Object[] arr = new Object[size];
        LinkedListNode<T> currentNode = head;
        for (int i = 0; i < size; i++) {
            arr[i] = currentNode.getData();
            currentNode = currentNode.getNext();
        }
        return arr;
    }

    /**
     * Returns a boolean value indicating if the list is empty.
     *
     * Must be O(1) for all cases.
     *
     * @return true if empty; false otherwise
     */
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        }
        return false;
    }

    /**
     * Clears the list of all data.
     *
     * Must be O(1) for all cases.
     */
    public void clear() {
        head = null;
        size = 0;
    }

    /**
     * Returns the number of elements in the list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the size of the list
     */
    public int size() {
        // DO NOT MODIFY!
        return size;
    }

    /**
     * Returns the head node of the linked list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return node at the head of the linked list
     */
    public LinkedListNode<T> getHead() {
        // DO NOT MODIFY!
        return head;
    }
}