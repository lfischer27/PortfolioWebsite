import org.junit.Before;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

public class SAUnitTest {

    private static final int TIMEOUT = 200;
    private static final int CAPACITY = MaxHeap.INITIAL_CAPACITY;
    private MaxHeap<Integer> maxHeap;
    private Integer[] expected;
    private ArrayList<Integer> data;

    @Before
    public void setUp() {
        maxHeap = new MaxHeap<>();
        expected = new Integer[CAPACITY];
        data = new ArrayList<>(
                List.of(87, 43, 68, 6, 77, 33, 9, 11, 19, 99, 6, 23, 89, 2, 14,
                        1, 5, 27, 35, 7, 42, 12, 71, 3, 67, 22));
    }

    @Test(timeout = TIMEOUT)
    public void testNoArgsConstructor() {
        assertTrue(maxHeap.isEmpty());
        assertEquals(0, maxHeap.size());
        assertEquals(CAPACITY, maxHeap.getBackingArray().length);
        assertArrayEquals(expected, maxHeap.getBackingArray());
    }

    @Test(timeout = TIMEOUT)
    public void testConstructor() {
        maxHeap = new MaxHeap<>(data);
        assertEquals(data.size() * 2 + 1, maxHeap.getBackingArray().length);
        assertEquals(data.size(), maxHeap.size());
        assertFalse(maxHeap.isEmpty());
        expected = new Integer[data.size() * 2 + 1];
        List.of(99, 87, 89, 35, 77, 68, 14, 11, 27, 43, 71, 67, 33, 2, 9, 1, 5,
                6, 19, 7, 42, 12, 6, 3, 23, 22).toArray(expected);
        checkArray();
    }

    private ArrayList<Integer> generateList(int min, int max) {
        ArrayList<Integer> toReturn = new ArrayList<>();
        for (int i = min; i <= max; i++) {
            toReturn.add(i);
        }
        return toReturn;
    }

    @Test(timeout = TIMEOUT)
    public void testAdd() {
        maxHeap = new MaxHeap<>();
        assertEquals(0, maxHeap.size());
        assertEquals(CAPACITY, maxHeap.getBackingArray().length);
        assertArrayEquals(expected, maxHeap.getBackingArray());
        for (Integer curr : data.subList(0, CAPACITY - 1)) {
            maxHeap.add(curr);
        }
        assertEquals(12, maxHeap.size());
        assertEquals(CAPACITY, maxHeap.getBackingArray().length);

        List.of(99, 87, 68, 19, 77, 33, 9, 6, 11, 43, 6, 23).toArray(expected);
        checkArray();

        maxHeap.add(data.get(CAPACITY - 1));
        assertEquals(13, maxHeap.size());
        assertEquals(CAPACITY * 2, maxHeap.getBackingArray().length);

        for (Integer curr : data.subList(CAPACITY, data.size() - 1)) {
            maxHeap.add(curr);
        }
        assertEquals(data.size() - 1, maxHeap.size());
        assertEquals(CAPACITY * 2, maxHeap.getBackingArray().length);

        maxHeap.add(data.get(data.size() - 1));
        assertEquals(data.size(), maxHeap.size());
        assertEquals(CAPACITY * 4, maxHeap.getBackingArray().length);

        expected = new Integer[CAPACITY * 4];
        List.of(99, 87, 89, 35, 77, 68, 14, 6, 27, 43, 71, 67, 33, 2, 9, 1, 5,
                11, 19, 7, 42, 6, 12, 3, 23, 22).toArray(expected);
        checkArray();
    }

    @Test(timeout = TIMEOUT)
    public void testAddTwo() {
        maxHeap = new MaxHeap<>(new ArrayList<>(data.subList(0, 11)));
        assertEquals(11, maxHeap.size());
        assertEquals(23, maxHeap.getBackingArray().length);

        expected = new Integer[23];
        List.of(99, 87, 68, 19, 77, 33, 9, 11, 6, 43, 6).toArray(expected);
        checkArray();

        for (Integer curr : data.subList(maxHeap.size(), 22)) {
            maxHeap.add(curr);
        }
        assertEquals(22, maxHeap.size());
        assertEquals(23, maxHeap.getBackingArray().length);
        List.of(99, 87, 89, 35, 77, 68, 14, 11, 27, 43, 12, 23, 33, 2, 9, 1, 5,
                6, 19, 7, 42, 6).toArray(expected);
        checkArray();

        for (Integer curr : data.subList(maxHeap.size(), data.size())) {
            maxHeap.add(curr);
        }
        assertEquals(data.size(), maxHeap.size());
        assertEquals(46, maxHeap.getBackingArray().length);
        expected = new Integer[46];
        List.of(99, 87, 89, 35, 77, 68, 14, 11, 27, 43, 71, 67, 33, 2, 9, 1, 5,
                6, 19, 7, 42, 6, 12, 3, 23, 22).toArray(expected);
        checkArray();
    }

    private void checkArray() {
        for (int i = 1; i < expected.length; i++) {
            assertEquals(expected[i - 1], maxHeap.getBackingArray()[i]);
        }
    }


    @Test(timeout = TIMEOUT)
    public void testRemove() {
        data = generateList(0, 5);
        maxHeap = new MaxHeap<>();
        for (Integer curr : data) {
            maxHeap.add(curr);
        }
        data.clear();
        data.addAll(List.of(5, 3, 4, 0, 2, 1, 4, 3, 1, 0, 2, 3, 2,
                            1, 0, 2, 0, 1, 1, 0, 0));
        while (!maxHeap.isEmpty()) {
            List<Integer> subList = data.subList(0, maxHeap.size());
            subList.toArray(expected);
            checkArray();
            assertEquals(maxHeap.getMax(), maxHeap.remove());
            assertEquals(subList.size() - 1, maxHeap.size());
            data = new ArrayList<>(data.subList(subList.size(), data.size()));
            expected = new Integer[CAPACITY];
        }
    }

    @Test(timeout = TIMEOUT)
    public void testGetMaxAndEmptyAndClear() {
        maxHeap = new MaxHeap<>();
        assertEquals(0, maxHeap.size());
        assertNull(maxHeap.getMax());
        assertArrayEquals(expected, maxHeap.getBackingArray());
        maxHeap.add(19);
        maxHeap.add(2);
        assertEquals((Integer) 19, maxHeap.getMax());
        maxHeap.add(38);
        assertEquals((Integer) 38, maxHeap.getMax());
        while (!maxHeap.isEmpty()) {
            maxHeap.remove();
        }
        assertEquals(0, maxHeap.size());
        assertNull(maxHeap.getMax());
        assertArrayEquals(expected, maxHeap.getBackingArray());

        maxHeap = new MaxHeap<>(data);
        assertEquals(maxHeap.size(), data.size());
        assertEquals((Integer) 99, maxHeap.getMax());
        assertEquals((Integer) 99, maxHeap.remove());
        assertEquals((Integer) 89, maxHeap.remove());
        assertEquals((Integer) 87, maxHeap.getMax());
        assertFalse(maxHeap.isEmpty());

        maxHeap.clear();
        assertTrue(maxHeap.isEmpty());
        assertEquals(0, maxHeap.size());
        assertNull(maxHeap.getMax());
        assertArrayEquals(expected, maxHeap.getBackingArray());
    }


}