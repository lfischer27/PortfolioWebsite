import java.util.ArrayList;
import java.util.NoSuchElementException;

/**
 * Your implementation of a max heap.
 *
 * @author Lauren Fischer
 * @userid lfischer7
 * @GTID 903393056
 * @version 1.0
 */
public class MaxHeap<T extends Comparable<? super T>> {

    // DO NOT ADD OR MODIFY THESE INSTANCE/CLASS VARIABLES.
    public static final int INITIAL_CAPACITY = 13;

    private T[] backingArray;
    private int size;

    /**
     * Creates a Heap with an initial capacity of INITIAL_CAPACITY
     * for the backing array.
     *
     * Use the constant field provided. Do not use magic numbers!
     */
    public MaxHeap() {
        backingArray = (T[]) new Comparable[INITIAL_CAPACITY];
    }

    /**
     * Creates a properly ordered heap from a set of initial values.
     *
     * You must use the BuildHeap algorithm that was taught in lecture! Simply
     * adding the data one by one using the add method will not get any credit.
     * As a reminder, this is the algorithm that involves building the heap
     * from the bottom up by repeated use of downHeap operations.
     *
     * The data in the backingArray should be in the same order as it appears
     * in the passed in ArrayList before you start the Build Heap Algorithm.
     *
     * The backingArray should have capacity 2n + 1 where n is the
     * number of data in the passed in ArrayList (not INITIAL_CAPACITY from
     * the interface). Index 0 should remain empty, indices 1 to n should
     * contain the data in proper order, and the rest of the indices should
     * be empty.
     *
     * @param data a list of data to initialize the heap with
     * @throws IllegalArgumentException if data or any element in data is null
     */
    public MaxHeap(ArrayList<T> data) {
        if (data == null) {
            throw new IllegalArgumentException(
                    "cannot add from an empty Arraylist");
        }
        backingArray = (T[]) new Comparable[2 * data.size() + 1];
        for (T datum : data) {
            if (datum == null) {
                throw new IllegalArgumentException("cannot add null element");
            }
            backingArray[size + 1] = datum;
            size++;
        }
        for (int i = size / 2; i > 0; i--) {
            downHeap(i);
        }
    }


    /**
     * Adds an item to the heap. If the backing array is full and you're trying
     * to add a new item, then double its capacity.
     *
     * @throws IllegalArgumentException if the item is null
     * @param item the item to be added to the heap
     */
    public void add(T item) {
        if (item == null) {
            throw new IllegalArgumentException("cannot add null item");
        }
        if (size == backingArray.length - 1) {
            T[] newArray = (T[]) new Comparable[backingArray.length * 2];
            for (int i = 1; i < size + 1; i++) {
                newArray[i] = backingArray[i];
            }
            backingArray = newArray;
        }
        backingArray[size + 1] = item;
        size++;
        upHeap(size);
    }

    /**
     * Compares the data of the passed in index with parent's
     * data and swaps them if the order property is violated
     *
     * @param index the index of the data being compared
     */

    private void upHeap(int index) {
        if (index / 2 == 0) {
            return;
        }
        int parentIndex = index / 2;
        if (backingArray[index].compareTo(backingArray[parentIndex]) > 0) {
            T data = backingArray[index];
            backingArray[index] = backingArray[parentIndex];
            backingArray[parentIndex] = data;
            upHeap(parentIndex);
        }
    }

    /**
     * Removes and returns the max item of the heap. As usual for array-backed
     * structures, be sure to null out spots as you remove. Do not decrease the
     * capacity of the backing array.
     *
     * @throws java.util.NoSuchElementException if the heap is empty
     * @return the removed item
     */
    public T remove() {
        if (size == 0) {
            throw new NoSuchElementException("cannot remove from empty heap");
        }
        T data = backingArray[1];
        backingArray[1] = backingArray[size];
        backingArray[size] = null;
        size--;
        downHeap(1);
        return data;
    }

    /**
     * Compares the data of the passed in index with it's children's
     * data and swaps them if the order property is violated
     *
     * @param index the index of the data being observed
     */

    private void downHeap(int index) {
        int maxIndexNum = maxIndex(2 * index, 2 * index + 1);
        if (maxIndexNum == 0) {
            return;
        }
        if (backingArray[index].compareTo(backingArray[maxIndexNum]) < 0) {
            T data = backingArray[index];
            backingArray[index] = backingArray[maxIndexNum];
            backingArray[maxIndexNum] = data;
            downHeap(maxIndexNum);
        }
    }

    /**
     * Compares the data of the left and right children and
     * returns the index of the node with the greater data;
     * returns 0 if both children are null
     *
     * @param indexLeft the index of the left child
     * @param indexRight the index of the right child
     * @return returns index of the child with the greater data or
     * returns 0 if both children are null
     */

    private int maxIndex(int indexLeft, int indexRight) {
        if (indexLeft > size) {
            return 0;
        } else if (indexRight > size) {
            return indexLeft;
        } else if (backingArray[indexLeft].
                compareTo(backingArray[indexRight]) < 0) {
            return indexRight;
        } else {
            return indexLeft;
        }
    }

    /**
     * Returns the maximum element in the heap.
     *
     * @return the maximum element, null if the heap is empty
     */
    public T getMax() {
        if (size == 0) {
            return null;
        }
        return backingArray[1];
    }

    /**
     * Returns if the heap is empty or not.
     *
     * @return true if the heap is empty, false otherwise
     */
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        }
        return false;
    }

    /**
     * Clears the heap and rests the backing array to a new array of capacity
     * {@code INITIAL_CAPACITY}.
     */
    public void clear() {
        T[] newArray = (T[]) new Comparable[INITIAL_CAPACITY];
        backingArray = newArray;
        size = 0;
    }

    /**
     * Returns the size of the heap.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return number of items in the heap
     */
    public int size() {
        // DO NOT MODIFY THIS METHOD!
        return size;
    }

    /**
     * Returns the backing array of the heap.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the backing array of the heap
     */
    public Object[] getBackingArray() {
        // DO NOT MODIFY THIS METHOD!
        return backingArray;
    }

}