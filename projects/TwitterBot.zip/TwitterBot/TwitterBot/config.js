// Twitter App keys
module.exports = {
  consumer_key:         'skGWIRWWkk53nw0cUb0SMrDfk',
  consumer_secret:      'FxL2JBhZ6KoL8ALNkW3uhdX5Wt07oBlnNGpgUJDklZLo5HIBDn',
  access_token:         '1191198480267563008-lzXfeW62S9PhxOEdyvWjnTBIU3lsBF',
  access_token_secret:  'v4DEQnPorMMiGdgmB0bLyE26VAd6qYTIeG23pGM1DrJIk'
}

// Clarifai key
var myApiKey = '2598a4aeeb034daaa01c2540a3f6b1c7'; 

