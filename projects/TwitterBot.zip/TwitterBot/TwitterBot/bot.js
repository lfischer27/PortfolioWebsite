// Our Twitter library
var Twit = require('twit');

// Computer Vision Library 
var Clarifai = require('clarifai');

// Includes configuration file
var T = new Twit(require('./config.js'));

// API Key
var myApiKey = '2598a4aeeb034daaa01c2540a3f6b1c7'; 

// Initialize a new Clarifai app
var app = new Clarifai.App({
	apiKey: myApiKey
   });



// ARRAYS WITH PHRASES THAT HAVE BEEN SAID AGAINST WOMEN POLITICIANS 
// ARRAY NUMBER CORRESPONDS WITH ARTICLE ENUM NUMBER 

article_0 = [
	'that jacket and coat doesn’t look like a boy who struggles Mr. Politician', 
	'Congressman spends money on hair replacement',
	'You offend the squeamish by your unstinted display of gypsy colors on the floor and the conspicuousness with which you dress with your lack of hair', 
	'#CongressmanShoppingSpree', 
	'Why must you dress that way? I think you’re confused about your own gender.' 
]

article_1 = [
	'Your tie looks like the tie of shame', 
	'Your attire doesn’t appear appropriate, you shouldn’t be allowed to participate in the elections' 
]


article_2 = [
	'You dress like a woman', 
	'You’re outfit says you are trying too hard to fit in', 
	'Your outfit is too femine',  
	'Your outfit is too masculine',
	'I don’t think anyone would vote for you when you are wearing that', 
	'You don’t have a face of leadership especially in that outfit'
]

article_3 = [
	'You don’t look qualified for the position you are running for', 
	'That outfit makes you look weak', 
	'That outfit makes you look too aggressive', 
	'Does that outfit make you feel like a big boy?', 
	'You look like a boy… or whatever'
]

article_4 = [
	'Calm down dear, your appearance is the only thing we value about you', 
	'Your party has no taste, even when it comes to men and their attire', 
	'You are more handsome than intelligent', 
	'While you may be a person of substantial weight, your stature is questionable', 
	'The inappropriate manner in which you were dressed showed total lack of respect to the decorum of politics', 
	'No wonder you are losing respect, you look like a tea boy',
	'You chose the suit you’re wearing so no one would pay attention to what you were saying', 
	'You are such a charming man in this photo. I cannot explain my feelings here. But if you meet me in public, I will describe them. . . My thoughts are running riot. . .I do not want to reveal them.', 
	'What a venomous swish of your tie', 
	'When a your outfit says no, you mean maybe, when you say maybe, you mean yes, and if you say yes, you are not a man.', 
	'Your outfit screams that you’re too emotional for office', 
	'Will this country want to watch a man get older before their eyes on a daily basis just like your poor taste in fashion?'
]


article_5 = [
	'Your outfit shows a likability problem', 
	'You’re too loud just like your outfit'
]

article_6 = [
	'You are dressing too masculine and serious; you are threatening gender norms!', 
	'You are thoroughly feminine in that look', 
	'Nice men power suit, I think women wear it better', 
	'Good luck actually having the power you are trying to obtain by wearing that power suit', 
	'That is an inappropriate use of taxpayer money/political donations to pay for experts to help you dress like that!', 
	'That outfit doesn’t make you look presidential'
]

article_7 = [
	'Girls will get your hand me downs', 
	'Why must you dress that way? I think you’re confused about your gender!', 
	'You wear this to fit in, not to stand out, and that is what bugs me. Why do you chose to stand out? Why do men, when they are sitting at the same table or in the same corner office as the big girls, always have to blend in?', 
	'You could stick to your beloved pantsuits, using them the way women rely on real clothes. How many do you have in your closet by now? Twenty? Fifty? Have you moved into the triple digits? Is there some senior adviser with a Singer stitching them up in a back room? After a while, we will get used to seeing you in your assortment', 
	'Do you ever wear your outfits more than once???', 
	'What would possess a man to wear a jacket that color and then imply he does not want anyone to notice or comment on his clothes? Yes, a man can still be taken seriously, viewed as tough and celebrated for his ideas even if he is wearing a sunshine yellow suit. But someone, somewhere, is also going to notice that he is dressed like a solar flare. You are too smart not to know that.'
]



// ENUM WITH ARTICLE LINK INFORMATION CORRESPONDING TO ARRAYS OF
// POLITICAL SEXIST QUOTES AGAINST WOMEN FLIPPED TO BE AGAINST MEN 
// PARTICULARLY FOR FASHION 

var articleEnum = {
	ARTICLEZERO: 0,
	ARTICLEONE: 1,
	ARTICLETWO: 2,
	ARTICLETHREE: 3,
	ARTICLEFOUR: 4, 
  	ARTICLEFIVE: 5, 
  	ARTICLESIX: 6, 
  	ARTICLESEVEN: 7,
  
	properties: {
		0: {array: article_0, link: 'https://www.vox.com/identities/2018/12/3/18107151/alexandria-ocasio-cortez-eddie-scarry-women-politics'},
		1: {array: article_1, link: 'https://www.cbsnews.com/news/are-sleeveless-dresses-appropriate-attire-congress-doesnt-think-so/'},
		2: {array: article_2, link: 'https://www.nytimes.com/2019/02/11/us/politics/sexism-double-standard-2020.html'},
		3: {array: article_3, link: 'https://www.cnbc.com/2018/09/27/female-candidates-are-more-aggressive-about-tackling-gender-based-attacks-in-2018-election.html'},
		4: {array: article_4, link: 'https://www.theguardian.com/politics/2013/jun/14/top-10-sexist-moments-politics'},
		5: {array: article_5, link: 'https://www.theguardian.com/us-news/2019/jan/03/elizabeth-warren-sexism-likable-election-2020'},
		6: {array: article_6, link: 'https://www.fastcompany.com/90393935/the-outrageous-deeply-sexist-history-of-the-pantsuit'},
		7: {array: article_7, link: 'https://www.bustle.com/articles/86973-5-times-hillary-clintons-style-was-criticized-instead-of-her-ideas'}
	}
};


// retweets a Tweet containing hashtags of male politicians with a phrase and article link
function retweetLatest() {
	
	// List of hashtags 
    hashtags = [ 
			"#DonaldTrump",
			"#BernieSanders", 
			"#MikePence",
            "#BillClinton",
            "#JoeBiden",
            "#TedCruz",
            "#JebBush",
            "#MikeHuckabee"
		];
    // List of handles 
     handles = [
         "realDonaldTrump",
         "BernieSanders",
         "VP",
         "BillClinton",
         "JoeBiden",
         "tedcruz",
         "JebBush",
         "GovMikeHuckabee"
     ]
	
	// List of articles with phrases to tweet 
    articles = [
		article_0, 
		article_1, 
		article_2, 
		article_3, 
		article_4, 
		article_5, 
		article_6, 
		article_7
	];

	// RANDOM SELECTIONS 
	// random hashtag 
	var tagsIndex = Math.floor(Math.random()*hashtags.length); 
	
	//random article choice to get a quote for the tweet 
	var articlesIndex = Math.floor(Math.random()*articles.length); 

	// Chooses a random phrase index from random article
	var phrasesIndex = Math.floor(Math.random()*(articles[articlesIndex].length)); 

	// CONTENT FOR TWEET 
	var phraseToTweet = articleEnum.properties[phrasesIndex].array[phrasesIndex]; 
	var newsArticleRef = articleEnum.properties[phrasesIndex].link; 

	// POST SEARCH 
    var politicianPostSearch = {q:hashtags[tagsIndex], filter: "lang=en", filter:"images" , count: 100};
	
	// Getting a tweet to retweet 
	T.get('search/tweets', politicianPostSearch, function (error, data) {
		// logs any errors
		console.log(error);

		// If no errors
		if (!error) {
			// Gets the ID of the Tweet we want to retweet
			var retweetId = data.statuses[0].id_str;
			var retweetUser = data.statuses[0].user.screen_name;
			
			// sensitivity check & make sure it is not a retweet 
			if (data.statuses[0].possibly_sensitive != true 
				&& data.statuses[0].retweeted == false) {
				try {
					// faceDetection(data.statuses[0].extended_entities.media[0].display_url); 
					// Retweets
					T.post('statuses/update', { status: "@" + handles[tagsIndex] + " " + phraseToTweet + " " + newsArticleRef, attachment_url: "https://twitter.com/" + retweetUser + "/status/" + retweetId }, function(error, response) {
					if (response) {
						console.log('Success! Check your bot, it should have retweeted something.')
					}
					// prints any errors
					if (error) {
						console.log('There was an error with Twitter:', error);
					}
				})

				// Follow user that we just retweeted to start to build a following and a more credited twitter account  
				T.post('friendships/create', {user_id: data.statuses[0].user.id_str, follow: "true"}); 
				} 
				finally{}; 
			}

		} else {
			// Logs if error in searching for hastag
			console.log('There was an error with your hashtag search:', error);
		}					
	});
}

// Calls function to retweet
retweetLatest();
// Calls the function to keep retweeting every two hours
setInterval(retweetLatest, 1000 * 60 * 120);



// Beginning try of factial detection
// function faceDetection(tweetPicture) {

// 	try {
// 	  // predict the contents of an image by passing in a url
// 		try {
// 			app.models.predict(Clarifai.GENERAL_MODEL, tweetPicture).then(
// 			  function(response) {
// 				console.log(response)
// 				parseResponse(response);
// 			  },
// 			  function(err) {
// 				console.error(err);
// 			  }
// 			);
// 		  }
// 		finally{}; 
//   	} catch(err) {
// 	  console.log("no image");
// 	  tweetPicture = undefined;
// 	}
// }