import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Queue;
import java.util.PriorityQueue;

/**
 * implementation of various different graph algorithms.
 */
public class GraphAlgorithms {

    /**
     * Performs a breadth first search (bfs) on the input graph, starting at
     * {@code start} which represents the starting vertex.
     * <p>
     * When exploring a vertex, make sure to explore in the order that the
     * adjacency list returns the neighbors to you. Failure to do so may cause
     * you to lose points.
     * <p>
     * You may import/use {@code java.util.Set}, {@code java.util.List},
     * {@code java.util.Queue}, and any classes that implement the
     * aforementioned interfaces, as long as it is efficient.
     * <p>
     * The only instance of {@code java.util.Map} that you may use is the
     * adjacency list from {@code graph}. DO NOT create new instances of Map
     * for BFS (storing the adjacency list in a variable is fine).
     * <p>
     * DO NOT modify the structure of the graph. The graph should be unmodified
     * after this method terminates.
     *
     * @param <T>   the generic typing of the data
     * @param start the vertex to begin the bfs on
     * @param graph the graph to search through
     * @return list of vertices in visited order
     * @throws IllegalArgumentException if any input
     * is null, or if {@code start} doesn't exist in the graph
     */
    public static <T> List<Vertex<T>> bfs(Vertex<T> start, Graph<T> graph) {
        if (start == null) {
            throw new IllegalArgumentException("cannot use null start");
        }
        if (graph == null) {
            throw new IllegalArgumentException("cannot use null graph");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("start does not exist in graph");
        }
        Queue<Vertex<T>> bfsQ = new LinkedList<Vertex<T>>();
        bfsQ.add(start);
        Set<Vertex<T>> visited = new HashSet<Vertex<T>>();
        LinkedList<Vertex<T>> returnList = new LinkedList<Vertex<T>>();
        while (!bfsQ.isEmpty()) {
            Vertex<T> removed = bfsQ.remove();
            if (!visited.contains(removed)) {
                returnList.add(removed);
                visited.add(removed);
                List<VertexDistance<T>> adj = graph.getAdjList().get(removed);
                for (VertexDistance<T> vert : adj) {
                    if (!visited.contains(vert.getVertex())) {
                        ((LinkedList<Vertex<T>>) bfsQ).add(vert.getVertex());
                    }
                }
            }
        }
        return returnList;
    }

    /**
     * Performs a depth first search (dfs) on the input graph, starting at
     * {@code start} which represents the starting vertex.
     * <p>
     * When exploring a vertex, make sure to explore in the order that the
     * adjacency list returns the neighbors to you. Failure to do so may cause
     * you to lose points.
     * <p>
     * *NOTE* You MUST implement this method recursively, or else you will lose
     * most if not all points for this method.
     * <p>
     * You may import/use {@code java.util.Set}, {@code java.util.List}, and
     * any classes that implement the aforementioned interfaces, as long as it
     * is efficient.
     * <p>
     * The only instance of {@code java.util.Map} that you may use is the
     * adjacency list from {@code graph}. DO NOT create new instances of Map
     * for DFS (storing the adjacency list in a variable is fine).
     * <p>
     * DO NOT modify the structure of the graph. The graph should be unmodified
     * after this method terminates.
     *
     * @param <T>   the generic typing of the data
     * @param start the vertex to begin the dfs on
     * @param graph the graph to search through
     * @return list of vertices in visited order
     * @throws IllegalArgumentException if any input
     * is null, or if {@code start} doesn't exist in the graph
     */
    public static <T> List<Vertex<T>> dfs(Vertex<T> start, Graph<T> graph) {
        if (start == null) {
            throw new IllegalArgumentException("cannot use null start");
        }
        if (graph == null) {
            throw new IllegalArgumentException("cannot use null graph");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("start does not exist in graph");
        }
        Set<Vertex<T>> visited = new HashSet<Vertex<T>>();
        LinkedList<Vertex<T>> returnList = new LinkedList<Vertex<T>>();
        Vertex<T> removed = start;
        dfsHelp(start, visited, returnList, graph);
        return returnList;
    }

    /**
     * recursive helper method for dfs
     * @param <T>   the generic typing of the data
     * @param vertx the vertex to run the dfs on
     * @param set visited set
     * @param list returnList
     * @param graph the graph to search through
     *
     */
    private static <T> void dfsHelp(Vertex<T> vertx, Set<Vertex<T>> set,
                                    LinkedList<Vertex<T>> list,
                                    Graph<T> graph) {
        set.add(vertx);
        list.add(vertx);
        List<VertexDistance<T>> adj = graph.getAdjList().get(vertx);
        for (VertexDistance<T> vert : adj) {
            if (!set.contains(vert.getVertex())) {
                dfsHelp(vert.getVertex(), set, list, graph);
            }
        }
    }

    /**
     * Finds the single-source shortest distance between the start vertex and
     * all vertices given a weighted graph (you may assume non-negative edge
     * weights).
     * <p>
     * Return a map of the shortest distances such that the key of each entry
     * is a node in the graph and the value for the key is the shortest distance
     * to that node from {@code start}, or Integer.MAX_VALUE (representing
     * infinity) if no path exists.
     * <p>
     * You may import/use {@code java.util.PriorityQueue},
     * {@code java.util.Map}, and {@code java.util.Set} and any class that
     * implements the aforementioned interfaces, as long as your use of it
     * is efficient as possible.
     * <p>
     * You should implement the version of Dijkstra's where you use two
     * termination conditions in conjunction.
     * <p>
     * 1) Check that not all vertices have been visited.
     * 2) Check that the PQ is not empty yet.
     * <p>
     * DO NOT modify the structure of the graph. The graph should be unmodified
     * after this method terminates.
     *
     * @param <T>   the generic typing of the data
     * @param start the vertex to begin the Dijkstra's on (source)
     * @param graph the graph we are applying Dijkstra's to
     * @return a map of the shortest distances from {@code start} to every
     * other node in the graph
     * @throws IllegalArgumentException if any input is null, or if start
     *                                  doesn't exist in the graph.
     */
    public static <T> Map<Vertex<T>, Integer> dijkstras(Vertex<T> start,
                                                        Graph<T> graph) {
        if (start == null) {
            throw new IllegalArgumentException("cannot use null start");
        }
        if (graph == null) {
            throw new IllegalArgumentException("cannot use null graph");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("start does not exist in graph");
        }
        HashMap<Vertex<T>, Integer> distMap = new HashMap<Vertex<T>, Integer>();
        Queue<VertexDistance<T>> pQ = new PriorityQueue<VertexDistance<T>>();
        pQ.add(new VertexDistance<T>(start, 0));
        Set<Vertex<T>> visited = new HashSet<Vertex<T>>();
        for (Vertex<T> vert : graph.getVertices()) {
            distMap.put(vert, Integer.MAX_VALUE);
        }
        distMap.put(start, 0);
        while (!pQ.isEmpty() && visited.size() != distMap.size()) {
            VertexDistance<T> dist = pQ.remove();
            if (!visited.contains(dist.getVertex())) {
                visited.add(dist.getVertex());
                List<VertexDistance<T>> adj =
                        graph.getAdjList().get(dist.getVertex());
                for (VertexDistance<T> vert : adj) {
                    int cost = vert.getDistance() + dist.getDistance();
                    if (!visited.contains(vert.getVertex())
                            && distMap.get(vert.getVertex()) > cost) {
                        distMap.put(vert.getVertex(), cost);
                        VertexDistance<T> dist2 = new
                                VertexDistance<T>(vert.getVertex(), cost);
                        pQ.add(dist2);
                    }
                }
            }
        }
        return distMap;
    }


    /**
     * Runs Prim's algorithm on the given graph and returns the Minimum
     * Spanning Tree (MST) in the form of a set of Edges. If the graph is
     * disconnected and therefore no valid MST exists, return null.
     * <p>
     * You may assume that the passed in graph is undirected. In this framework,
     * this means that if (u, v, 3) is in the graph, then the opposite edge
     * (v, u, 3) will also be in the graph, though as a separate Edge object.
     * <p>
     * The returned set of edges should form an undirected graph. This means
     * that every time you add an edge to your return set, you should add the
     * reverse edge to the set as well. This is for testing purposes. This
     * reverse edge does not need to be the one from the graph itself; you can
     * just make a new edge object representing the reverse edge.
     * <p>
     * You may assume that there will only be one valid MST that can be formed.
     * <p>
     * You should NOT allow self-loops or parallel edges in the MST.
     * <p>
     * You may import/use {@code java.util.PriorityQueue},
     * {@code java.util.Set}, and any class that implements the aforementioned
     * interface.
     * <p>
     * DO NOT modify the structure of the graph. The graph should be unmodified
     * after this method terminates.
     * <p>
     * The only instance of {@code java.util.Map} that you may use is the
     * adjacency list from {@code graph}. DO NOT create new instances of Map
     * for this method (storing the adjacency list in a variable is fine).
     *
     * @param <T>   the generic typing of the data
     * @param start the vertex to begin Prims on
     * @param graph the graph we are applying Prims to
     * @return the MST of the graph or null if there is no valid MST
     * @throws IllegalArgumentException if any input
     * is null, or if {@code start} doesn't exist in the graph
     */
    public static <T> Set<Edge<T>> prims(Vertex<T> start, Graph<T> graph) {
        if (start == null) {
            throw new IllegalArgumentException("cannot use null start");
        }
        if (graph == null) {
            throw new IllegalArgumentException("cannot use null graph");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("start does not exist in graph");
        }
        Set<Vertex<T>> visited = new HashSet<Vertex<T>>();
        Set<Edge<T>> mst = new HashSet<Edge<T>>();
        Queue<Edge<T>> pQ = new PriorityQueue<Edge<T>>();
        visited.add(start);
        for (VertexDistance<T> vd : graph.getAdjList().get(start)) {
            Edge<T> line = new Edge<T>(start, vd.getVertex(), vd.getDistance());
            pQ.add(line);
        }
        while (!pQ.isEmpty() && visited.size() != graph.getVertices().size()) {
            Edge<T> edge = pQ.remove();
            if (!visited.contains(edge.getV())) {
                visited.add(edge.getV());
                mst.add(edge);
                mst.add(new Edge<T>(edge.getV(), edge.getU(), edge.getWeight()));
                for (VertexDistance<T> vd
                        : graph.getAdjList().get(edge.getV())) {
                    Edge<T> line = new Edge<T>(edge.getV(),
                            vd.getVertex(), vd.getDistance());
                    if (!visited.contains(vd.getVertex())) {
                        pQ.add(line);
                    }
                }
            }
        }
        if (mst.size() == 2 * (graph.getVertices().size() - 1)) {
            return mst;
        } else {
            return null;
        }
    }
}