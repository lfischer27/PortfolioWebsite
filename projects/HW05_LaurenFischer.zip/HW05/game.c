#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "ship.h"
#include "spriteSheet2.h"

// Variables
BULLET bullets[BULLETCOUNT];
PLAYER spaceShip;
ENEMY enemies[ENEMYCOUNT];
int enemiesRemaining;
int playerLives;


// Initializes game
void initGame() {

	initPlayer();
	initEnemies();
    initBullets();

	enemiesRemaining = ENEMYCOUNT;
	enShooting = rand()%26;
	playerLives = 5; 

}

// Updates game every frame
void updateGame() {

	updatePlayer();

	// Updates all the bullets
	for (int i = 0; i < BULLETCOUNT; i++)
		updateBullet(&bullets[i]);

	// Updates all the enemies
	for (int i = 0; i < ENEMYCOUNT; i++)
		updateEnemies(&enemies[i]);
}

// Draws game every frame
void drawGame() {

	drawPlayer();
	drawEnemies();

	// Draws all the bullets
	for (int i = 0; i < BULLETCOUNT; i++)
		drawBullet(&bullets[i]);

	// Copies shadowOAM into OAM
		DMANow(3, shadowOAM, OAM, 128*4);

}

// Initializes Player
void initPlayer() {
	DMANow(3, spriteSheet2Tiles, &CHARBLOCK[4], spriteSheet2TilesLen/2);
	DMANow(3, spriteSheet2Pal, SPRITEPALETTE, 256);
	spaceShip.width = 44;
    spaceShip.height = 58;
    spaceShip.cdel = 1;
    spaceShip.rdel = 1;
	spaceShip.aniState = 0;
    spaceShip.curFrame = 0;
	spaceShip.bulletTimer = 20;
	spaceShip.col = SCREENWIDTH/2-spaceShip.height/2;
	spaceShip.row = 120;
	spaceShip.enTimer = 60;
	spaceShip.enTimerLimit = rand()%100+70;
}

// Updates player
void updatePlayer() {

	// if left button pressed, move left
    if(BUTTON_HELD(BUTTON_LEFT)) {
        if (spaceShip.col > 0) {
		    spaceShip.col--;
        }
	}
	// if right button pressed, move right
	if(BUTTON_HELD(BUTTON_RIGHT)) {
        if (spaceShip.col + spaceShip.width < SCREENWIDTH ) {
		    spaceShip.col++;
        }
	}

	//handles bullet-player collisions
	for (int i = 0; i < BULLETCOUNT; i++) {
		if (bullets[i].active && bullets[i].type == 1 && collision(spaceShip.col, spaceShip.row, spaceShip.width, spaceShip.height,
			bullets[i].col, bullets[i].row, bullets[i].width, bullets[i].height)) {
				bullets[i].active = 0;
				playerLives--;
		}
	}

	// Fires enemy bullets
	if (spaceShip.enTimer >= spaceShip.enTimerLimit) {
		// Makes sure the shooting enemy is active
		while(!enemies[enShooting].active) {
			enShooting = rand()%26;
		}
		fireBullet(1);
		//resets timer and timer limit
		spaceShip.enTimer = 0;
		spaceShip.enTimerLimit = rand() % 100 + 70;
		enShooting = rand()%26;
	}

	// Fires player bullets
	if (BUTTON_PRESSED(BUTTON_A) && spaceShip.bulletTimer >= 20) {
		fireBullet(0);
		spaceShip.bulletTimer = 0;
	}

	// Increments timers
	spaceShip.bulletTimer++;
	spaceShip.enTimer++;
}

// Draws player
void drawPlayer() {

	shadowOAM[0].attr0 = (ROWMASK & spaceShip.row) | ATTR0_4BPP | ATTR0_SQUARE;
	shadowOAM[0].attr1 = (COLMASK & spaceShip.col) | ATTR1_LARGE;
	shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0,0);

}

// Initializes pool of bullets
void initBullets() {
	//player bullets
	for (int i = 0; i < 5; i++) {
		bullets[i].width = 1;
		bullets[i].height = 6;
		bullets[i].col = 0;
		bullets[i].row = -bullets[i].height;
		bullets[i].oldCol = spaceShip.col;
		bullets[i].oldRow = spaceShip.row;
		bullets[i].rdel = -2;
		bullets[i].active = 0;
		bullets[i].oamIndex = i + 26;
		bullets[i].type = 0;
	}
	//enemy bullets
	for (int i = 5; i < 10; i++) {
		bullets[i].width = 1;
		bullets[i].height = 3;
		bullets[i].col = 0;
		bullets[i].row = -bullets[i].height;
		bullets[i].oldCol = spaceShip.col;
		bullets[i].oldRow = spaceShip.row;
		bullets[i].rdel = -2;
		bullets[i].active = 0;
		bullets[i].oamIndex = i + 26;
		bullets[i].type = 1;
	}
}

// Shoots bullet
void fireBullet(int bulletType) {

	// Find the first inactive player bullet
	for (int i = 0; i < BULLETCOUNT; i++) {
		if (bulletType == 0 && !bullets[i].active && bullets[i].type == bulletType) {

			// sets column, row, and active for bullet
			bullets[i].col = spaceShip.col + spaceShip.width/2 - bullets[i].width/2+2;
			bullets[i].row = spaceShip.row;
			bullets[i].active = 1;
			break;

		// Find the first inactive enemy bullet
		} else if (bulletType == 1 && !bullets[i].active && bullets[i].type == bulletType) {

			// sets column, row, and active for bullet
			bullets[i].col = enemies[enShooting].col + enemies[enShooting].width/2 - bullets[i].width/2;
			bullets[i].row = enemies[enShooting].row + enemies[enShooting].width;
			bullets[i].active = 1;
			break;

		}
	}
}

// Updates bullet
void updateBullet(BULLET* b) {

	// move player bullet
	if (b->active && b->type == 0) {
		if (b->row + b->height-1 >= 0) {
			b->row += b->rdel;
		} else {
			b->active = 0;
		}
	//move enemy bullet
	} else if (b->active && b->type == 1) {
		if (b->row < SCREENHEIGHT) {
			b->row -= b->rdel;
		} else {
			b->active = 0;
		}
	}
}

// Draws bullet
void drawBullet(BULLET* b) {
	// draws player bullet
	if(b->active && b->type == 0) {
		shadowOAM[b->oamIndex].attr0 = b->row | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[b->oamIndex].attr1 = b->col | ATTR1_TINY;
		shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(16,1);
	// Draws enemy bullet
	} else if(b->active && b->type == 1) {
		shadowOAM[b->oamIndex].attr0 = b->row | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[b->oamIndex].attr1 = b->col | ATTR1_TINY;
		shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(15,1);
	} 
	// hides sprite if inactive
	else {
		shadowOAM[b->oamIndex].attr0 = b->row | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
	}
}

// Initializes enemies
void initEnemies() {
	for (int i = 0; i < 5; i++) {
		enemies[i].row = 0;
		enemies[i].col = 34  + i * 40;
		enemies[i].width = 18;
		enemies[i].height = 16;
		enemies[i].type = 0;
		enemies[i].active = 1;
	}
	for (int i = 5; i < 10; i++) {
		enemies[i].row = 20;
		enemies[i].col = 34  + (i-5) * 40;
		enemies[i].width = 18;
		enemies[i].height = 16;
		enemies[i].type = 1;
		enemies[i].active = 1;
	}
	for (int i = 10; i < 15; i++) {
		enemies[i].row = 40;
		enemies[i].col = 32  + (i-10) * 40;
		enemies[i].width = 21;
		enemies[i].height = 9;
		enemies[i].type = 2;
		enemies[i].active = 1;
	}
	for (int i = 15; i < 20; i++) {
		enemies[i].row = 51;
		enemies[i].col = 34  + (i-15) * 40;
		enemies[i].width = 18;
		enemies[i].height = 16;
		enemies[i].type = 0;
		enemies[i].active = 1;
	}
	for (int i = 20; i < 25; i++) {
		enemies[i].row = 70;
		enemies[i].col = 34  + (i-20) * 40;
		enemies[i].width = 18;
		enemies[i].height = 16;
		enemies[i].type = 1;
		enemies[i].active = 1;
	}
}

// Updates Enemies
void updateEnemies(ENEMY* e) {
	// Checks enemy-bullet collision
	for (int i = 0; i < BULLETCOUNT; i++) {
		if (bullets[i].active && e->active && bullets[i].type == 0 && collision(e->col, e->row, e->width, e->height,
			bullets[i].col, bullets[i].row, bullets[i].width, bullets[i].height)) {
				bullets[i].active = 0;
				e->active = 0;
				enemiesRemaining--;
		}
	}
}

// Draws Enemies
void drawEnemies() {
	for (int i = 0; i < ENEMYCOUNT; i++) {
		if (enemies[i].active && enemies[i].type == 0) {
			shadowOAM[1+i].attr0 = enemies[i].row | ATTR0_4BPP | ATTR0_WIDE;
			shadowOAM[1+i].attr1 = enemies[i].col | ATTR1_MEDIUM;
			shadowOAM[1+i].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(10,1);
		} else if (enemies[i].active && enemies[i].type == 1) {
			shadowOAM[1+i].attr0 = enemies[i].row | ATTR0_4BPP | ATTR0_WIDE;
			shadowOAM[1+i].attr1 = enemies[i].col | ATTR1_MEDIUM;
			shadowOAM[1+i].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(18,1);
		} else if (enemies[i].active && enemies[i].type == 2) {
			shadowOAM[1+i].attr0 = enemies[i].row | ATTR0_4BPP | ATTR0_WIDE;
			shadowOAM[1+i].attr1 = enemies[i].col | ATTR1_MEDIUM;
			shadowOAM[1+i].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(22,1);
		} 
		else  {
			shadowOAM[1+i].attr0 = enemies[i].row | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
		}
	}
}