
// Bullet Struct
typedef struct {
	int col;
	int row;
	int oldCol;
	int oldRow;
	int cdel;
	int rdel;
	int width;
	int height;
	int active;
	int oamIndex;
	int type;
} BULLET;

// Player Struct
typedef struct {
	int row;
	int col;
    int rdel;
    int cdel;
	int width;
    int height;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int bulletTimer;
	int enTimer;
	int enTimerLimit;
} PLAYER;

// Enemy Struct
typedef struct {
	int row;
	int col;
	int width;
    int height;
    int type;
	int active;
} ENEMY;

// Constants
#define BULLETCOUNT 10
#define ENEMYCOUNT 25

// Variables
extern BULLET bullets[BULLETCOUNT];
extern int enemiesRemaining;
int enShooting;
extern int playerLives;

// Prototypes
void initGame();
void updateGame();
void drawGame();
void initBullets();
void fireBullet();
void drawBullet(BULLET* b);
void initEnemies();
void updatePlayer();
void updateBullet(BULLET* b);
void updateEnemies(ENEMY* e);
void drawEnemies();
void initPlayer();
void drawPlayer();