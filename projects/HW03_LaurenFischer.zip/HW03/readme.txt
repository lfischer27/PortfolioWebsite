press the up and down arrows to move your player, the orange fish, up and down respectively
if you collide with the big blue fish you get eaten and lose a life (lives are shown at the bottom left corner)
if you collide with a small magenta fish, press the A button to eat it and gain a life
if you have no lives left, you lose
if you get to 5 lives you win!