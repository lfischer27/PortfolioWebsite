#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "text.h"

// declarations
void initialize();
void start();
void game();
void pause();
void win();
void lose();
void goToStart();
void goToGame();
void goToPause();
void goToWin();
void goToLose();

// states
enum {START, GAME, WIN, LOSE};
int state;

// buttons
unsigned short buttons;
unsigned short oldButtons;

// random seed
int seed;

int main() {

    initialize();

    while(1) {

        // updates buttons
        oldButtons = buttons;
        buttons = BUTTONS;
                
        // state machine
        switch (state) {
            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;   
    }
}
}

// set up game conditions
void initialize() {

    REG_DISPCTL = MODE3 | BG2_ENABLE;

    goToStart();

}

//start state
void start() {
    seed++;
    if (BUTTON_PRESSED(BUTTON_START)) {
        srand(seed);
        initGame();
        goToGame();
    }
}

//game state
void game() {
    updateGame();
    waitForVBlank();
    drawGame();
    if (lives == 0) {
        goToLose();
    }

    if (lives == 5) {
        goToWin();
    }

    if (BUTTON_PRESSED(BUTTON_B)) {
        goToLose();
    }

}

//win state
void win() {
    if (BUTTON_PRESSED(BUTTON_START)) {
        goToStart();
    }
}

//lose state
void lose() {
    if (BUTTON_PRESSED(BUTTON_START)) {
        goToStart();
    }
}

//transition to start state
void goToStart() {
    state = START;
    fillScreen(SKY);
    drawString(80, 70, "Press Start", BLUE);
}

//transition to game state
void goToGame() {
    state = GAME;
    fillScreen(CYAN);
    drawFirstLife (ORANGE);
    drawSecondLife (ORANGE);
    drawThirdLife (ORANGE);
    updateGame();
}

//transition to win state
void goToWin() {
    state = WIN;
    fillScreen(GREEN);
    drawString(90, 70, "You Win!", BLACK);
}

//transition to lose state
void goToLose() {
    state = WIN;
    fillScreen(RED);
    drawString(50, 70, "Better Luck Next Time", BLACK);
}