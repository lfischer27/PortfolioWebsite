// Player Struct
typedef struct {
	int row;
	int col;
	int oldRow;
	int oldCol;
	int rdel;
	int height;
	int width;
	unsigned short color;
	int bubbleTimer;
	int bfishTimer;
	int sfishTimer;
	int bfishTimerLimit;
	int sfishTimerLimit;
} PLAYER;

// Bubble Struct
typedef struct {
	int row;
	int col;
	int oldRow;
	int oldCol;
	int rdel;
	int height;
	int width;
	unsigned short color;
	int active;
	int erased;
} BUBBLE;


// Big Fish Struct
typedef struct {
	int row;
	int col;
	int oldRow;
	int oldCol;
	int cdel;
	int height;
	int width;
	unsigned short color;
	int active;
	int erased;
} BFISH;

// Small Fish Struct
typedef struct {
	int row;
	int col;
	int oldRow;
	int oldCol;
	int cdel;
	int height;
	int width;
	unsigned short color;
	int active;
	int erased;
} SFISH;

// constants for pools
#define BUBBLECOUNT 3
#define BFISHCOUNT 2
#define SFISHCOUNT 2

// extern variables
extern PLAYER player;
extern BUBBLE bubbles[BUBBLECOUNT];
extern BFISH bfishes[BFISHCOUNT];
extern SFISH sfishes[SFISHCOUNT];
extern int lives;

// function declarations
void initGame();
void updateGame();
void drawGame();
void drawBar();
void initPlayer();
void updatePlayer();
void drawPlayer();
void initBubbles();
void spawnBubbles();
void spawnBfish();
void spawnSfish();
void updateBubble(BUBBLE *);
void drawBubble(BUBBLE *);
void initBfishes();
void initSfishes();
void updateBfish(BFISH *);
void updateSfish(SFISH *);
void drawBfish(BFISH *);
void drawSfish(SFISH *);