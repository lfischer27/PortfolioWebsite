#include <stdlib.h>
#include "myLib.h"
#include "game.h"

// player, fish, bubble, and life variables
PLAYER player;
BUBBLE bubbles[BUBBLECOUNT];
BFISH bfishes[BFISHCOUNT];
SFISH sfishes[SFISHCOUNT];
int lives;

// sets up the game
void initGame() {

	initPlayer();
	initBubbles();
	initBfishes();
	initSfishes();
	lives = 3;
}

// updates the game
void updateGame() {

	// updates the player
	updatePlayer();

	// updates all the bubbles
	for (int i = 0; i < BUBBLECOUNT; i++) {
		updateBubble(&bubbles[i]);
	}

	// updates all the big fish
	for (int i = 0; i < BFISHCOUNT; i++) {
		updateBfish(&bfishes[i]);
	}

	// updates all the small fish
	for (int i = 0; i < SFISHCOUNT; i++) {
		updateSfish(&sfishes[i]);
	}

}

// draws the game
void drawGame() {

	//draws the player
	drawPlayer();

	// draws the bubbles
	for (int i = 0; i < BUBBLECOUNT; i++) {
		drawBubble(&bubbles[i]);
	}
	
	// draws the big fish
	for (int i = 0; i < BFISHCOUNT; i++) {
		drawBfish(&bfishes[i]);
	}

	// draws the small fish
	for (int i = 0; i < SFISHCOUNT; i++) {
		drawSfish(&sfishes[i]);
	}

}

// initializes player
void initPlayer() {
	player.row = 80;
	player.oldRow = player.row;
	player.col = 40;
	player.oldCol = player.col;
	player.rdel = 1;
	player.height = 10;
	player.width = 15;
	player.color = ORANGE;
	player.bubbleTimer = 40;
	player.bfishTimer = 40;
	player.sfishTimer = 40;
	player.bfishTimerLimit = rand()%100+70;
	player.sfishTimerLimit = rand()%100+70;
}

// initializes the pool of bubbles
void initBubbles() {

	// initializes bubbles
	for (int i = 0; i < BUBBLECOUNT; i++) {
		bubbles[i].active = 0;
		bubbles[i].height = 3;
		bubbles[i].width = 3;
		bubbles[i].col = 0;
		bubbles[i].oldCol = player.col;
		bubbles[i].row = -bubbles[i].height;
		bubbles[i].oldRow = player.row;
		bubbles[i].rdel = -1;
		bubbles[i].color = WHITE;
	}

}

// initializes pool of big fish
void initBfishes() {

	//initializes big fish
	for (int i = 0; i < BFISHCOUNT; i++) {
		bfishes[i].active = 1;
		bfishes[i].erased = 0;
		bfishes[i].height = 15;
		bfishes[i].width = 20;
		bfishes[i].col = rand() % 130 + 10;
		bfishes[i].oldCol = bfishes[i].col;
		bfishes[i].row = rand() % 110+10;
		bfishes[i].oldRow = bfishes[i].row;
		bfishes[i].cdel = -1;
		bfishes[i].color = BLUE;
	}
}

// initializes pool small fish
void initSfishes() {

	for (int i = 0; i < SFISHCOUNT; i++) {
		sfishes[i].active = 1;
		sfishes[i].erased = 0;
		sfishes[i].height = 5;
		sfishes[i].width = 8;
		sfishes[i].col = rand() % 130 + 10;
		sfishes[i].oldCol = sfishes[i].col;
		sfishes[i].row = rand() % 100+20;
		sfishes[i].oldRow = sfishes[i].row;
		sfishes[i].cdel = -1;
		sfishes[i].color = MAGENTA;
	}
}

// updates player
void updatePlayer() {

	//if up button pressed, moves player up and if down button is pressed, moves player down
	if (BUTTON_HELD(BUTTON_UP) && player.row >= player.rdel - 1) {

		player.row -= player.rdel;

	}else if (BUTTON_HELD(BUTTON_DOWN) && player.row + player.height-1  < SCREENHEIGHT - player.rdel) {

		player.row += player.rdel;

	}

	// causes bubbles to appear
	if (player.bubbleTimer >= 30) {
		spawnBubbles();
		player.bubbleTimer = 0;
	}

	//causes big fish to appear
	if (player.bfishTimer >= player.bfishTimerLimit) {
		spawnBfish();
		player.bfishTimer = 0;
		player.bfishTimerLimit = rand() % 100;
	}

	//causes small fish to appear
	if (player.sfishTimer >= player.sfishTimerLimit) {
		spawnSfish();
		player.sfishTimer = 0;
		player.sfishTimerLimit = rand() % 100;
	}

	//increments timers
	player.bubbleTimer++;
	player.bfishTimer++;
	player.sfishTimer++;

}

// updates bubble
void updateBubble(BUBBLE* b) {

	// moves active bubble up the screen and makes it inactive if it goes above the screen
	if (b->active == 1) {
		if (b->row < 0) {
			b->active = 0;
		} else {
			b->row += b->rdel;
		}
	}

}

// updates big fish
void updateBfish(BFISH* b) {

	// moves active big fish left and makes it inactive if it goes off the screen
	if (b->active) {

		if (b->col<= 0) {
			b->active = 0;
		}

		b->col += b->cdel;

		// if big fish collides with player, player loses a life and big fish is made inactive
		if (collision(player.col, player.row, player.width, player.height, b->col, b->row, b->width, b->height)) {
			if (lives == 4) {
				drawFourthLife(CYAN);
			}
			if (lives == 3) {
				drawThirdLife(CYAN);
			}
			if (lives == 2) {
				drawSecondLife(CYAN);
			}
			if (lives == 1) {
				drawFirstLife(CYAN);
			}
			lives--;
			b->active = 0;
			}

	}
}

// updates small fish
void updateSfish(SFISH* s) {

	// moves active small fish left and makes it inactive if it goes off the screen
	if (s->active) {

		if (s->col<= 0) {
			s->active = 0;
		}

		s->col += s->cdel;

		// if the player presses A while colliding with the small fish, the player gains a life and small fish is made inactive
		if (BUTTON_PRESSED(BUTTON_A) && collision(player.col, player.row, player.width, player.height, s->col, s->row, s->width, s->height)) {
			lives = lives + 1;
			if (lives == 4) {
				drawFourthLife(ORANGE);
			}
			if (lives == 3) {
				drawThirdLife(ORANGE);
			}
			if (lives == 2) {
				drawSecondLife(ORANGE);
			}
			s->active = 0;
			}

	}
}

// spawns bubbles
void spawnBubbles() {

	// activates and initializes first inactive bubble
	for (int i = 0; i < BUBBLECOUNT; i++) {
		if (bubbles[i].active == 0) {
			bubbles[i].active = 1;
			bubbles[i].row = player.row + 4;
			bubbles[i].col = player.col + player.width + (bubbles[i].width/2);
			bubbles[i].erased = 0;
			break;
		}
	}

}

// spawns big fish
void spawnBfish() {
	// activates and initializes first inactive big fish
	for (int i = 0; i < BFISHCOUNT; i++) {
		if (bfishes[i].active == 0) {
			bfishes[i].active = 1;
			bfishes[i].row = rand() % 110;
			bfishes[i].col = 210;
			bfishes[i].erased = 0;
			break;
		}
	}

}

// spawns small fish
void spawnSfish() {
	// activates and initializes first inactive small fish
	for (int i = 0; i < BFISHCOUNT; i++) {
		if (sfishes[i].active == 0) {
			sfishes[i].active = 1;
			sfishes[i].row = rand() % 110 + 10;
			sfishes[i].col = 220;
			sfishes[i].erased = 0;
			break;
		}
	}

}

// draws player
void drawPlayer() {
	//erases old player
	drawRect(player.oldCol, player.oldRow, player.width, player.height, CYAN);
	for (int j = 2; j < 4; j++) {
		for (int i=3; i < 6; i++) {
			setPixel(player.oldCol-j, player.oldRow+i, CYAN);
		}
	}
	for (int row = 2; row < 7; row++) {
		setPixel(player.oldCol-4, player.oldRow+row, CYAN);
	}
	setPixel(player.oldCol-1, player.oldRow+4, CYAN);
	//draws new player
	drawRect(player.col, player.row, player.width, player.height, player.color);
	setPixel(player.col+6, player.row+3, BLACK);
	setPixel(player.col+5, player.row+4, BLACK);
	setPixel(player.col+6, player.row+5, BLACK);
	setPixel(player.col+11, player.row+2, BLACK);
	for (int j = 2; j < 4; j++) {
		for (int i=3; i < 6; i++) {
			setPixel(player.col-j, player.row+i, player.color);
		}
	}
	for (int row = 2; row < 7; row++) {
		setPixel(player.col-4, player.row+row, player.color);
	}
	setPixel(player.col-1, player.row+4, player.color);
	setPixel(player.col+player.width-1, player.row+5, CYAN);

	player.oldRow = player.row;
	player.oldCol = player.col;
}

// draws bubble
void drawBubble(BUBBLE* b) {
	if(b->active) {
		//erases old bubble
		drawRect(b->oldCol, b->oldRow, b->width, b->height, CYAN);
		//draws new bubble
		drawRect(b->col, b->row, b->width, b->height, b->color);
	//erases bubble if inactive and not already erased
	} else if (!b->erased) {
		drawRect(b->oldCol, b->oldRow, b->width, b->height, CYAN);
		b->erased = 1;
	}
	b->oldRow = b->row;
	b->oldCol = b->col;
}


// draws big fish
void drawBfish(BFISH* b) {
	if(b->active) {
		//erases old big fish
		drawRect(b->oldCol, b->oldRow, b->width, b->height, CYAN);
		for (int j = 1; j < 3; j++) {
			for (int i=6; i < 9; i++) {
				setPixel(b->oldCol+b->width+j, b->oldRow+i, CYAN);
			}
		}
		setPixel(b->oldCol+b->width, b->oldRow+7, CYAN);
		for (int row = 5; row < 10; row++) {
			setPixel(b->oldCol+b->width+3, b->oldRow+row, CYAN);
		}
		//draws new big fish
		drawRect(b->col, b->row, b->width, b->height, b->color);
		for (int row = 2; row < 6; row++) {
			for (int col = 2; col < 6; col++) {
				setPixel(b->col+col, b->row+row, WHITE);
			} 
		}
		setPixel(b->col+3, b->row+3, BLACK);
		for (int row = 8; row < 12; row++) {
				setPixel(b->col, b->row+row, CYAN);
		}
		setPixel(b->col+10, b->row+6, BLACK);
		setPixel(b->col+11, b->row+7, BLACK);
		setPixel(b->col+10, b->row+8, BLACK);
		for (int j = 1; j < 3; j++) {
			for (int i=6; i < 9; i++) {
				setPixel(b->col+b->width+j, b->row+i, b->color);
			}
		}
		for (int row = 5; row < 10; row++) {
			setPixel(b->col+b->width+3, b->row+row, b->color);
		}
		setPixel(b->col+b->width, b->row+7, b->color);
	//erases small fish if inactive and not already erased
	} else if (!b->erased) {
		drawRect(b->oldCol, b->oldRow, b->width, b->height, CYAN);
		b->erased = 1;
		for (int j = 1; j < 3; j++) {
			for (int i=6; i < 9; i++) {
				setPixel(b->oldCol+b->width+j, b->oldRow+i, CYAN);
			}
		}
		setPixel(b->oldCol+b->width, b->oldRow+7, CYAN);
		for (int row = 5; row < 10; row++) {
			setPixel(b->oldCol+b->width+3, b->oldRow+row, CYAN);
		}
	}
	b->oldRow = b->row;
	b->oldCol = b->col;
}

// Draws small fish
void drawSfish(SFISH* s) {
	if(s->active) {
		//erases old small fish
		drawRect(s->oldCol, s->oldRow, s->width, s->height, CYAN);
			for (int i=1; i < 4; i++) {
				setPixel(s->oldCol+s->width+1, s->oldRow+i, CYAN);
			}
		setPixel(s->oldCol+s->width, s->oldRow+2, CYAN);
		//draws new small fish
		drawRect(s->col, s->row, s->width, s->height, s->color);
		setPixel(s->col+2, s->row+1, BLACK);
			for (int i=1; i < 4; i++) {
				setPixel(s->col+s->width+1, s->row+i, s->color);
			}
		setPixel(s->col+s->width, s->row+2, s->color);
	//erases small fish if inactive and not already erased
	} else if (!s->erased) {
		drawRect(s->oldCol, s->oldRow, s->width, s->height, CYAN);
		s->erased = 1;
		drawRect(s->oldCol, s->oldRow, s->width, s->height, CYAN);
			for (int i=1; i < 4; i++) {
				setPixel(s->oldCol+s->width+1, s->oldRow+i, CYAN);
			}
		setPixel(s->oldCol+s->width, s->oldRow+2, CYAN);
	}
	s->oldRow = s->row;
	s->oldCol = s->col;
}