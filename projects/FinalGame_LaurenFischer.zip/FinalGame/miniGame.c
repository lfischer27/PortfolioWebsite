#include "myLib.h"
#include "miniGame.h"
#include "collisionmap.h"
#include "myLib.h"

// Variables
int hOff2;
int movementTimer;
int movementTimerLimit;
OBJ_ATTR shadowOAM[128];
SPRITE player;
ENEMYTWO eye;
ROCK rocks[ROCKCOUNT];
int eyeCollide;
int playerLives;
int covered;
int distTraveled;
int endAniTimer;
int caught;

// player animation states for aniState
enum {RIGHT, LEFT, IDLE};

// Initialize the game
void initGame2() {

	// Place screen on map
    hOff2 = 9;
    movementTimer = 0;
	movementTimerLimit = 3;
    eyeCollide = 1;
    playerLives = 1;
    covered = 1;
    distTraveled = 0;
    endAniTimer = 0;
    caught = 0;

    initPlayer2();
    initEnemy();
    initRocks();
}

// Updates game
void updateGame2() {
    
	updatePlayer2();
    updateEnemy();
    updateRocks();
}

// Draws game
void drawGame2() {

    drawPlayer2();
    drawRocks();
    drawEnemy();

    // waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128*4);

    REG_BG2HOFF = hOff2;

}

// Initializes player
void initPlayer2() {

    player.width = 16;
    player.height = 16;
    player.rdel = 1;
    player.cdel = 1;
    player.worldRow = 120;
    player.worldCol = 20;
    player.aniCounter = 0;
    player.curFrame = 0;
    player.numFrames = 3;
    player.aniState = RIGHT;
}

// Updates player
void updatePlayer2() {

    // Scrolls background
    if(BUTTON_HELD(BUTTON_LEFT) && caught == 0) {

        // decrement distance traveled
        distTraveled--;

        // scroll until near the end of the mini game
        if (distTraveled < 660) {

            // decreases hOff
            hOff2--;

            // move rock overhangs in accordance with player
            for (int i = 0; i < ROCKCOUNT; i++) {
                rocks[i].col++;
            }

        // if towards end of game, just move the player
        } else {
            player.worldCol--;
        }
    }

    // Scrolls background
    if(BUTTON_HELD(BUTTON_RIGHT) && caught == 0) {

        // increment distance traveled
        distTraveled++;

        // scroll until near the end of the mini game
        if (distTraveled < 660) {
        
            // increases hOff
            hOff2++;

            // move rock overhangs in accordance with player
            for (int i = 0; i < ROCKCOUNT; i++) {
                rocks[i].col--;
            }

        // if towards end of game, just move the player
        } else {
            player.worldCol++;
        }
    }

    if (caught != 0) {
        endAniTimer++;
        if (endAniTimer > 160) {
            playerLives = 0;
        }
    }

    // if player tries to put on ring, game over
    if (cheatCount < 3 && BUTTON_PRESSED(BUTTON_B)) {
        eye.col = player.worldCol;
        caught = 1;
    }

    // waitForVBlank();

    // Updates offsets
    REG_BG2HOFF = hOff2;
    REG_BG3HOFF = hOff2/2;

    animatePlayer2();

    // if you reach the end of the mini game go ahead and jump to distance 900 for percision
    if (player.worldCol + player.width == 240) {
        distTraveled = 900;
    }
}

// Animates Player
void animatePlayer2() {

    // Set previous state to current state
    player.prevAniState = player.aniState;
    player.aniState = IDLE;

    // Changes animation frame
    if(player.aniCounter % 20 == 0) {
        player.curFrame = (player.curFrame + 1) % player.numFrames;
    }

    // Coordinates movement and animation state
    if(BUTTON_HELD(BUTTON_LEFT))
        player.aniState = LEFT;
    if(BUTTON_HELD(BUTTON_RIGHT))
        player.aniState = RIGHT;

    // If player is idle
    if (player.aniState == IDLE) {
        player.curFrame = 0;
        player.aniCounter = 0;
        player.aniState = player.prevAniState;
    } else {
        player.aniCounter++;
    }

    movementTimer++;
}

// Draws player
void drawPlayer2() {

    if (player.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else if (caught != 0) {
        shadowOAM[0].attr0 = (ROWMASK & player.worldRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.worldCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(8, 2*(endAniTimer/40));
    }else if (cheatCount >= 3) {
        shadowOAM[0].attr0 = (ROWMASK & player.worldRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.worldCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(21 + player.aniState * 2, player.curFrame * 2);
    } else {
        shadowOAM[0].attr0 = (ROWMASK & player.worldRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.worldCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(player.aniState * 2 + 4, player.curFrame * 2);
    }
}

// Initializes Eye
void initEnemy() {

		eye.width = 19;
		eye.height = 120;
		eye.cdel = 8;
		eye.index = 1;
		eye.active = 1;
        eye.row = 20;
        eye.col = 20;

}

// updates enemies
void updateEnemy() {

    // Moves eye if movement timer has gone off
    // eye reverses direction if it collides with the map edge
	if (caught == 0 && movementTimer > movementTimerLimit) {
        if (eye.cdel > 0) {
            if (eye.col + eye.width - 1 < 240) {
                eye.col += eye.cdel;
            } else {
                eye.cdel = -eye.cdel;
                eye.col += eye.cdel;
            }
        } else {
            if (eye.col > 0) {
                eye.col += eye.cdel;
            } else {
                if (eye.cdel > 0) {
                    eye.cdel = -1 * (distTraveled % 4 + 8);
                } else {
                    eye.cdel = distTraveled % 4 + 8;
                }
                eye.col += eye.cdel;
            }
		}
		movementTimer = 0;
    }

    // if player is seen by eye, player loses life
    if (cheatCount < 3 && covered == 0 && collision(eye.col, eye.row, eye.width, eye.height,
		player.worldCol, player.worldRow, player.width, player.height)) {
            // playerLives = 0;
            caught = 1;
    }
}

// Draws Enemy
void drawEnemy() {
	shadowOAM[1].attr0 = (ROWMASK & eye.row) | ATTR0_4BPP | ATTR0_TALL;
	shadowOAM[1].attr1 = (COLMASK & eye.col) | ATTR1_LARGE;
	shadowOAM[1].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(10,3);
    
    // if eye is not looking at a rock overhang, draw bottom half of eye's vision
    if (eyeCollide == 0) {
        shadowOAM[5].attr0 = (ROWMASK & (eye.row + 40)) | ATTR0_4BPP | ATTR0_TALL;
	    shadowOAM[5].attr1 = (COLMASK & eye.col) | ATTR1_LARGE;
	    shadowOAM[5].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(10,13);
    } else {
        shadowOAM[5].attr0 |= ATTR0_HIDE;
    }
}

// initializes rock overhangs
void initRocks(){
    for (int i = 0; i < ROCKCOUNT; i++) {
        rocks[i].row = 60;
        rocks[i].col = 20 + 90*i;
        rocks[i].width = 32;
        rocks[i].height = 8;
    }
}

// updates rock overhangs
void updateRocks() {
    int hit = 0;
    int hid = 0;

    for (int i = 0; i < ROCKCOUNT; i++) {

        // makes it so that the overhangs are in a consistent posisiton if they are 
        // at the edge of the screen and the player is moving back and forth
        if (rocks[i].col + rocks[i].width < 0) {
            rocks[i].col = 240;
        } else if (rocks[i].col > 240) {
            rocks[i].col = 0 - rocks[i].width;
        }

        // if eye is looking at a rock overhang, eyeCollide is set to 1 (true)
        if (collision(eye.col, eye.row, eye.width, eye.height,
			rocks[i].col, rocks[i].row, rocks[i].width, rocks[i].height)) {
                eyeCollide = 1;
                hit = 1;
        }

        // if the player is under a rock overhang, they are marked as covered
        if (player.worldCol >= rocks[i].col && player.worldCol + player.width < rocks[i].col + rocks[i].width) {
            hid = 1;
            covered = 1;
        }

    }

    // resets eyeCollide to 0 if the eye is not looking at an overhang
    if (hit == 0) {
        eyeCollide = 0;
    }

    // resets covered to 0 if the player is no longer under an overhang
    if (hid == 0) {
        covered = 0;
    }
}

// Draws Enemy
void drawRocks() {
    for (int i = 0; i < ROCKCOUNT; i++) {
	    shadowOAM[2+i].attr0 = (ROWMASK & rocks[i].row) | ATTR0_4BPP | ATTR0_WIDE;
	    shadowOAM[2+i].attr1 = (COLMASK & rocks[i].col) | ATTR1_SMALL;
	    shadowOAM[2+i].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0,7);
    }
}