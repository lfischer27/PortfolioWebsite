
//{{BLOCK(rulesBig2)

//======================================================================
//
//	rulesBig2, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 234 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 32 + 7488 + 2048 = 9568
//
//	Time-stamp: 2019-11-25, 19:50:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_RULESBIG2_H
#define GRIT_RULESBIG2_H

#define rulesBig2TilesLen 7488
extern const unsigned short rulesBig2Tiles[3744];

#define rulesBig2MapLen 2048
extern const unsigned short rulesBig2Map[1024];

#define rulesBig2PalLen 32
extern const unsigned short rulesBig2Pal[16];

#endif // GRIT_RULESBIG2_H

//}}BLOCK(rulesBig2)
