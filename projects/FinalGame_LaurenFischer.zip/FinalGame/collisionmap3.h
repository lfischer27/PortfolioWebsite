
//{{BLOCK(collisionmap3)

//======================================================================
//
//	collisionmap3, 300x300@16, 
//	+ bitmap not compressed
//	Total size: 180000 = 180000
//
//	Time-stamp: 2019-11-19, 15:24:01
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP3_H
#define GRIT_COLLISIONMAP3_H

#define collisionmap3BitmapLen 180000
extern const unsigned short collisionmap3Bitmap[90000];

#endif // GRIT_COLLISIONMAP3_H

//}}BLOCK(collisionmap3)
