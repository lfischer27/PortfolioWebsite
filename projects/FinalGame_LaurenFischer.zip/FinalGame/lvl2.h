
//{{BLOCK(lvl2)

//======================================================================
//
//	lvl2, 512x512@4, 
//	+ palette 256 entries, not compressed
//	+ 861 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x64 
//	Total size: 512 + 27552 + 8192 = 36256
//
//	Time-stamp: 2019-11-18, 22:23:51
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LVL2_H
#define GRIT_LVL2_H

#define lvl2TilesLen 27552
extern const unsigned short lvl2Tiles[13776];

#define lvl2MapLen 8192
extern const unsigned short lvl2Map[4096];

#define lvl2PalLen 512
extern const unsigned short lvl2Pal[256];

#endif // GRIT_LVL2_H

//}}BLOCK(lvl2)
