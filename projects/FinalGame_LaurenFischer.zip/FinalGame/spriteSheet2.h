
//{{BLOCK(spriteSheet2)

//======================================================================
//
//	spriteSheet2, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2019-10-31, 12:16:27
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITESHEET2_H
#define GRIT_SPRITESHEET2_H

#define spriteSheet2TilesLen 32768
extern const unsigned short spriteSheet2Tiles[16384];

#define spriteSheet2PalLen 512
extern const unsigned short spriteSheet2Pal[256];

#endif // GRIT_SPRITESHEET2_H

//}}BLOCK(spriteSheet2)
