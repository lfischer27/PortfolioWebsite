
//{{BLOCK(lavaGround)

//======================================================================
//
//	lavaGround, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 30 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 960 + 4096 = 5568
//
//	Time-stamp: 2019-11-12, 17:35:11
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LAVAGROUND_H
#define GRIT_LAVAGROUND_H

#define lavaGroundTilesLen 960
extern const unsigned short lavaGroundTiles[480];

#define lavaGroundMapLen 4096
extern const unsigned short lavaGroundMap[2048];

#define lavaGroundPalLen 512
extern const unsigned short lavaGroundPal[256];

#endif // GRIT_LAVAGROUND_H

//}}BLOCK(lavaGround)
