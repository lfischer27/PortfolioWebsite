
//{{BLOCK(Options)

//======================================================================
//
//	Options, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 587 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 32 + 18784 + 2048 = 20864
//
//	Time-stamp: 2019-11-11, 22:26:39
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_OPTIONS_H
#define GRIT_OPTIONS_H

#define OptionsTilesLen 18784
extern const unsigned short OptionsTiles[9392];

#define OptionsMapLen 2048
extern const unsigned short OptionsMap[1024];

#define OptionsPalLen 32
extern const unsigned short OptionsPal[16];

#endif // GRIT_OPTIONS_H

//}}BLOCK(Options)
