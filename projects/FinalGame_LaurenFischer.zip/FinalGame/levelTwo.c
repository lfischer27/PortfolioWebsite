#include "myLib.h"
#include "levelTwo.h"
#include "collisionmap3.h"
#include "lvl1.h"

// Variables
int hOff;
int vOff;
int movementTimer;
int movementTimerLimit;
OBJ_ATTR shadowOAM[128];
ANISPRITE player;
ENEMY3 enemies[ENEMYCOUNT2];
int pLives;
int fin;
int swing2;
int hidden;
int swingCounter;
int gollumCounter;
int prevCdel;
int prevRdel;
int caught;
int endAniTimer;

// animation states
enum {FRONT, BACK, RIGHT, LEFT, IDLE};

// Initialize game
void initGame3() {

	// set screen on map
    vOff = 140;
    hOff = 60;
    movementTimer = 0;
	movementTimerLimit = 5;
    pLives = 1;
    fin = 0;
    swing2 = 0;
    hidden = 0;
    swingCounter = 0;
    prevRdel = -1;
    caught = 0;
    endAniTimer = 0;

    initEnemies3();
    initPlayer3();
}

// Updates game
void updateGame3() {
    
	updatePlayer3();

    for (int i = 0; i < ENEMYCOUNT2; i++)
	updateEnemies3();
}

// Draws game
void drawGame3() {

    drawPlayer3();
    drawEnemies3();

    REG_BG0HOFF = hOff;
    REG_BG0VOFF = vOff;
}

// Initializes player
void initPlayer3() {

    player.width = 16;
    player.height = 16;
    player.rdel = 1;
    player.cdel = 1;

    // places player in world
    player.worldRow = 280;
    player.worldCol = 280;
    
    //animation settings
    player.aniCounter = 0;
    player.curFrame = 0;
    player.numFrames = 3;
    player.aniState = FRONT;
}

// Updates player
void updatePlayer3() {

    //moves player
    //keeps player within map while moving camera to keep player as centered as possible

    if(BUTTON_HELD(BUTTON_UP) && caught == 0) {
        if (player.worldRow > 0 && collisionmap3Bitmap[OFFSET(player.worldCol, player.worldRow - player.rdel, MAPWIDTH)] != BLACK &&
        collisionmap3Bitmap[OFFSET(player.worldCol + player.width - 1, player.worldRow - player.rdel, MAPWIDTH)] != BLACK) {
                    player.worldRow -= player.rdel;
                }

            if ( vOff>0 && player.screenRow +player.height/2 < SCREENHEIGHT/2) {

                vOff--;
            }
    }
    if(BUTTON_HELD(BUTTON_DOWN) && caught == 0) {
        if (player.screenRow + player.height < SCREENHEIGHT && collisionmap3Bitmap[OFFSET(player.worldCol, player.worldRow + player.height, MAPWIDTH)] != BLACK
        && collisionmap3Bitmap[OFFSET(player.worldCol + player.width - 1, player.worldRow + player.height, MAPWIDTH)] != BLACK) {

            player.worldRow += player.rdel;

            if ( vOff < MAPHEIGHT - SCREENHEIGHT && player.screenRow + player.height/2 > SCREENHEIGHT/2) {

                vOff++;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_LEFT) && caught == 0) {
        if (player.worldCol > 0 && collisionmap3Bitmap[OFFSET(player.worldCol - player.cdel, player.worldRow, MAPWIDTH)] != BLACK 
        && collisionmap3Bitmap[OFFSET(player.worldCol - player.cdel, player.worldRow + player.height - 1, MAPWIDTH)] != BLACK) {

            player.worldCol -= player.cdel;

            if ( player.screenCol < SCREENWIDTH/2 && hOff > 0) {

                hOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_RIGHT) && caught == 0) {
        if (player.worldCol + player.width - 1 < MAPWIDTH && collisionmap3Bitmap[OFFSET(player.worldCol + player.width, player.worldRow + player.height/2, MAPWIDTH)] != BLACK && collisionmap3Bitmap[OFFSET(player.worldCol + player.width, player.worldRow, MAPWIDTH)] != BLACK
        && collisionmap3Bitmap[OFFSET(player.worldCol+ player.width, player.worldRow + player.height - 1, MAPWIDTH)] != BLACK) {

            player.worldCol += player.cdel;

            if ( player.screenCol + player.width - 1 > SCREENWIDTH/2  && player.worldCol + SCREENWIDTH - player.screenCol < MAPWIDTH) {

                hOff++;
            }
        }
    }

    // updates screen position
    player.screenRow = player.worldRow - vOff;
    player.screenCol = player.worldCol - hOff;


    animatePlayer3();
    
    for (int i = 0; i < ENEMYCOUNT2; i++) {

        // handles player enemy collisions
		if (cheatCount < 3 && hidden == 0 && enemies[i].active && collision(player.worldCol, player.worldRow, player.width, player.height,
			enemies[i].worldCol, enemies[i].worldRow, enemies[i].width, enemies[i].height)) {
				caught = 1;
                break;
		}

        // checks if player's attack has hit enemy
        if (swing2 == 1 && enemies[i].active && collision(player.worldCol - 5, player.worldRow - 5, player.width + 10, player.height + 10,
			enemies[i].worldCol, enemies[i].worldRow, enemies[i].width, enemies[i].height)) {
				enemies[i].active = 0;
                // swing2 = 0;
                break;
		}

	}

    // swing2 = 0;

    // if player has reached the end of the level set fin to 1
    if (player.worldCol >= 150 && player.worldCol <= 160 && player.worldRow >= 185 && player.worldRow <= 200) {
        fin = 1;
    }

    if (caught != 0) {
        for (int i = 0; i < ENEMYCOUNT2; i++) {
            enemies[i].cdel = 0;
            enemies[i].rdel = 0;
        }
        endAniTimer++;
        if (endAniTimer > 160) {
            pLives = 0;
        }
    }

}

// animation of player
void animatePlayer3() {

    // Sets previous state to current state
    player.prevAniState = player.aniState;
    player.aniState = IDLE;

    // Changes animation frame
    if(player.aniCounter % 20 == 0) {
        player.curFrame = (player.curFrame + 1) % player.numFrames;
    }

    // Coordinates movement and animation state
    if(BUTTON_HELD(BUTTON_UP))
        player.aniState = BACK;
    if(BUTTON_HELD(BUTTON_DOWN))
        player.aniState = FRONT;
    if(BUTTON_HELD(BUTTON_LEFT))
        player.aniState = LEFT;
    if(BUTTON_HELD(BUTTON_RIGHT))
        player.aniState = RIGHT;

    // accounts for idle player
    if (player.aniState == IDLE) {
        player.curFrame = 0;
        player.aniCounter = 0;
        player.aniState = player.prevAniState;
    } else {
        player.aniCounter++;
    }

    movementTimer++;
}

// Draws player
void drawPlayer3() {

    if (player.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else if ((hidden == 1 || cheatCount >= 3) && swing2 == 1) {
        shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_SMALL;
        if (player.aniState == RIGHT){
            if (swingCounter > 18) {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 3 + 2*(swingCounter/6));
            } else {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 11 + 2*(swingCounter/6));
            }
        } else if (player.aniState == LEFT){
            if (swingCounter > 3) {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 3 + 2*(swingCounter/3));
            } else {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 15 + 2*(swingCounter/3));
            }
        } else if (player.aniState == BACK){
            if (swingCounter > 6) {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 3 + 2*(swingCounter/3));
            } else {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 13 + 2*(swingCounter/3));
            }
        }
        else {
            shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(26, 3 + 2*(swingCounter/3));
        }
        swingCounter++;
        if (player.aniState != BACK && swingCounter >= 24) {
            swingCounter = 0;
            swing2 = 0;
        } else if (player.aniState == LEFT && swingCounter >= 21) {
            swingCounter = 0;
            swing2 = 0;
        } else if (player.aniState == RIGHT && swingCounter >= 21) {
            swingCounter = 0;
            swing2 = 0;
        }
          else if (player.aniState == BACK && swingCounter > 15) {
            swingCounter = 0;
            swing2 = 0;
        }
    } else if (swing2 == 1) {
        shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_SMALL;
        if (player.aniState == RIGHT){
            if (swingCounter > 18) {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 3 + 2*(swingCounter/6));
            } else {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 11 + 2*(swingCounter/6));
            }
        } else if (player.aniState == LEFT){
            if (swingCounter > 3) {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 3 + 2*(swingCounter/3));
            } else {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 15 + 2*(swingCounter/3));
            }
        } else if (player.aniState == BACK){
            if (swingCounter > 6) {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 3 + 2*(swingCounter/3));
            } else {
                shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 13 + 2*(swingCounter/3));
            }
        }
        else {
            shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(14, 3 + 2*(swingCounter/3));
        }
        swingCounter++;
        if (player.aniState != BACK && swingCounter >= 24) {
            swingCounter = 0;
            swing2 = 0;
        } else if (player.aniState == LEFT && swingCounter >= 21) {
            swingCounter = 0;
            swing2 = 0;
        } else if (player.aniState == RIGHT && swingCounter >= 21) {
            swingCounter = 0;
            swing2 = 0;
        }
          else if (player.aniState == BACK && swingCounter > 15) {
            swingCounter = 0;
            swing2 = 0;
        }
    } else if (hidden == 1 || cheatCount >=3) {
        shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(17 + player.aniState * 2, player.curFrame * 2);
    }  else if (caught != 0) {
        shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(8, 2*(endAniTimer/40));
    } else {
        shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(player.aniState * 2, player.curFrame * 2);
    }
}

// animation of enemy
void animateEnemy3() {

    for (int i = 0; i < ENEMYCOUNT2; i++) {
    // Sets previous state to current state
    enemies[i].prevAniState = enemies[i].aniState;
    enemies[i].aniState = IDLE;

    // increments animation frame
    if(enemies[i].aniCounter % 5 == 0) {
        enemies[i].curFrame = (enemies[i].curFrame + 1) % enemies[i].numFrames;
    }

    // changed animation state based on movement
    if(enemies[i].rdel > 0)
        enemies[i].aniState = BACK;
    if(enemies[i].rdel < 0)
        enemies[i].aniState = FRONT;
    if(enemies[i].cdel < 0)
        enemies[i].aniState = LEFT;
    if(enemies[i].cdel > 0)
        enemies[i].aniState = RIGHT;

    // if (caught == 1) {
    //     enemies[i].aniCounter = 1;
    // } else {
        enemies[i].aniCounter++;
    // }
    }

}

// Draws Enemies
void drawEnemies3() {
    for (int i = 0; i < 2; i++) {
        // only want to draw when we see the enemy on the screen
        // so if world row < 160 to get rid of the mask doubles
		if (enemies[i].active && player.worldRow < 160) {
			shadowOAM[1+i].attr0 = ((enemies[i].worldRow - vOff) & ROWMASK) | ATTR0_4BPP | ATTR0_SQUARE;
			shadowOAM[1+i].attr1 = ((enemies[i].worldCol - hOff) & COLMASK) | ATTR1_SMALL;
			shadowOAM[1+i].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(enemies[i].aniState * 2, 9 +  enemies[i].curFrame * 2);
        } else {
            shadowOAM[1+i].attr0 = ATTR0_HIDE;
        }
    }
    // only want to draw when we see the enemy on the screen
    // so if world row < 160 to get rid of the mask doubles
	if (enemies[2].active) {
		shadowOAM[3].attr0 = ((enemies[2].worldRow - vOff) & ROWMASK) | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[3].attr1 = ((enemies[2].worldCol - hOff) & COLMASK) | ATTR1_SMALL;
		shadowOAM[3].attr2 = ATTR2_PALROW(2) | ATTR2_TILEID(enemies[2].aniState * 2, 16 +  enemies[2].curFrame * 2);
    } else {
        shadowOAM[3].attr0 = ATTR0_HIDE;
    }
}

// Initializes Enemies
void initEnemies3() {
	for (int i = 0; i < 2; i++) {

		enemies[i].width = 16;
		enemies[i].height = 16;
		enemies[i].type = 0;
		enemies[i].active = 1;
        if (i == 0) {
		    enemies[i].cdel = 4;
        } else {
            enemies[i].cdel = 2;
        }
        enemies[i].rdel = 0;
		enemies[i].aniState = 0;
        if (i == 0) {
            enemies[i].worldRow = 30;
        } else {
            enemies[i].worldRow = 2;
        }
        // enemies[i].worldRow = 20 + i*20;
        enemies[i].worldCol = 20;

        //animation settings
        enemies[i].aniCounter = 0;
        enemies[i].curFrame = 0;
        enemies[i].numFrames = 3;
        enemies[i].aniState = FRONT;


	}
    // Gollum
    	enemies[2].width = 16;
		enemies[2].height = 16;
		enemies[2].type = 1;
		enemies[2].active = 1;
		enemies[2].cdel = 1;
        enemies[2].rdel = 0;
		enemies[2].aniState = 0;
        enemies[2].worldRow = 70;
        enemies[2].worldCol = 2;

        //animation settings
        enemies[2].aniCounter = 0;
        enemies[2].curFrame = 0;
        enemies[2].numFrames = 3;
        enemies[2].aniState = FRONT;

}

//updates enemies
void updateEnemies3() {

    // Moves enemies if movement timer has gone off
    // enemies reverse direction if they collide with the map edge or the collision map
	if (movementTimer > movementTimerLimit) {
		for (int i = 0; i < ENEMYCOUNT2; i++) {
            if (caught == 0) {
                if (enemies[i].cdel > 0) {
                    if (enemies[i].worldCol + enemies[i].width - 1 < MAPWIDTH && collisionmap3Bitmap[OFFSET(enemies[i].worldCol + enemies[i].width, enemies[i].worldRow, MAPWIDTH)] != BLACK
                    && collisionmap3Bitmap[OFFSET(enemies[i].worldCol+ enemies[i].width, enemies[i].worldRow + enemies[i].height - 1, MAPWIDTH)] != BLACK) {
                     enemies[i].worldCol += enemies[i].cdel;
                     enemies[i].worldRow += enemies[i].rdel;
                     if ((i == 2) && enemies[i].worldRow > 200) {
                         enemies[i].rdel = -enemies[i].rdel;
                     }
                    } else {
                        enemies[i].cdel = -enemies[i].cdel;
                        enemies[i].worldCol += enemies[i].cdel;
                    }
                } else {
                    if (enemies[i].worldCol > 0 && collisionmap3Bitmap[OFFSET(enemies[i].worldCol - enemies[i].cdel, enemies[i].worldRow, MAPWIDTH)] != BLACK
                     && collisionmap3Bitmap[OFFSET(enemies[i].worldCol - enemies[i].cdel, enemies[i].worldRow + enemies[i].height - 1, MAPWIDTH)] != BLACK) {
                          enemies[i].worldCol += enemies[i].cdel;
                    } else {
                        enemies[i].cdel = -enemies[i].cdel;
                        enemies[i].worldCol += enemies[i].cdel;
                    }
    		    }

                if (enemies[2].worldRow == 70) {
                    enemies[2].rdel = 1;
                }



                animateEnemy3();
    		    movementTimer = 0;
            }
	    }
    }
}