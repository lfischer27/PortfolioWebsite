
//{{BLOCK(collisionmap)

//======================================================================
//
//	collisionmap, 300x300@16, 
//	+ bitmap not compressed
//	Total size: 180000 = 180000
//
//	Time-stamp: 2019-11-18, 16:51:11
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP_H
#define GRIT_COLLISIONMAP_H

#define collisionmapBitmapLen 180000
extern const unsigned short collisionmapBitmap[90000];

#endif // GRIT_COLLISIONMAP_H

//}}BLOCK(collisionmap)
