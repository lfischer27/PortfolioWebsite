
#include "myLib.h"
#include "game.h"
#include "miniGame.h"
#include "spritesheet.h"
#include "pause.h"
#include "lose.h"
#include "win.h"
#include "Mordors.h"
#include "Options.h"
#include "lava.h"
#include "lavaG.h"
#include "lvl1.h"
#include "levelTwo.h"
#include "lvl2.h"
#include "lotr.h"
#include "sound.h"
#include "rulesBig1.h"
#include "rulesBig2.h"
#include "precious.h"


void initialize();

// State Functions
void goToStart();
void start();
void goToOptions();
void options();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();
void miniGame();
void goToMiniGame();
void level2();
void goToLevel2();
void rules1();
void goToRules1();
void rules2();
void goToRules2();

// States
enum {START, RULES1, RULES2, GAME, MINIGAME, LEVEL2, PAUSE, WIN, LOSE};
int state;

// Keeps track of wheter game, level2, or mini game is being paused
int beforePause = 0;

int timeCount;
int timeCount2;
int soundLen;
int justPlayed = 0;

int hideTimer = 0;
int startCounting = 0;

int cheatCount = 0;

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

int main() {

    initialize();

    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;
                
        // State Machine
        switch(state) {

            case START:
                start();
                break;
            case RULES1:
                rules1();
                break;
            case RULES2:
                rules2();
                break;
            case GAME:
                game();
                break;
            case MINIGAME:
                miniGame();
                break;
            case LEVEL2:
                level2();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
        }
               
    }
}

// Set Up
void initialize() {

    setupSounds();
	setupInterrupts();
    
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;
    hideSprites();
    goToStart();

}

// Sets up start state
void goToStart() {

    // loads in Mordor tile palette
    DMANow(3, MordorsPal, PALETTE, 256);

    // loads background
	REG_BG1CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;

	// loads Mordor tiles to charblock
    DMANow(3, MordorsTiles, &CHARBLOCK[0], MordorsTilesLen / 2);

    // loads Mordor map to screenblock
    DMANow(3, MordorsMap, &SCREENBLOCK[31], MordorsMapLen/2);

    // sets state to START
    state = START;

    stopSound();
}

// every frame of start state
void start() {

    waitForVBlank();

    // if start button pressed, go to rules 1 screen
    if (BUTTON_PRESSED(BUTTON_START)) {

        goToRules1();
        
    }
}

// Sets up the rules 1 state
void goToRules1() {

    // loads rules 1 tile palette
    DMANow(3, rulesBig1Pal, PALETTE, 256);

    // loads background
	REG_BG1CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;

	// loads rules 1 tiles to charblock
    DMANow(3, rulesBig1Tiles, &CHARBLOCK[0], rulesBig1TilesLen / 2);

    // loads rules 1 map to screenblock
    DMANow(3, rulesBig1Map, &SCREENBLOCK[31], rulesBig1MapLen/2);

    // sets state to RULES1
    state = RULES1;

}

// every frame of rules 1 state
void rules1() {

    waitForVBlank();

    // if start button pressed, go to rules 2
    if (BUTTON_PRESSED(BUTTON_START)) {

        goToRules2();
    }
}

// Sets up the rules 2 state
void goToRules2() {

    // loads rules 2 tile palette
    DMANow(3, rulesBig2Pal, PALETTE, 256);

    // loads background
	REG_BG1CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;

	// loads rules 2 tiles to charblock
    DMANow(3, rulesBig2Tiles, &CHARBLOCK[0], rulesBig2TilesLen / 2);

    // loads rules 2 map to screenblock
    DMANow(3, rulesBig2Map, &SCREENBLOCK[31], rulesBig2MapLen/2);

    // sets state to RULES2
    state = RULES2;

    timeCount = 0;
}

// every frame of rules 2 state
void rules2() {
    waitForVBlank();

    // if start button pressed, start game
    if (BUTTON_PRESSED(BUTTON_START)) {

        stopSound();
        // plays non looping sound of Gollum saying "preciousss" to start
        playSoundB(precious, PRECIOUSLEN, PRECIOUSFREQ, 0);
        // sets justPlayed to 1 to indicate nonlooping sound has played
        justPlayed = 1;

        goToGame();
        initGame();
    }
}

// Sets up the game state
void goToGame() {

    // lvl1 background
    DMANow(3, lvl1Pal, PALETTE, 256);
    DMANow(3, lvl1Tiles, &CHARBLOCK[0], lvl1TilesLen/2);
    DMANow(3, lvl1Map, &SCREENBLOCK[28], lvl1MapLen/2);
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(28) | BG_SIZE_LARGE;


    // sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen/2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen/2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128*4);

    // enables mode, background, and sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;

    // sets state to GAME
    state = GAME;

    // makes note that game is the current state for refrence in pause state
    beforePause = 0;

    timeCount = 0;
}

// Runs every frame of the game state
void game() {

    timeCount++;
    buttons = BUTTONS;
    updateGame();
    drawGame();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128*4);

    if (startCounting == 1) {
        hideTimer++;
        if (hideTimer > 200) {
            hidden = 0;
            startCounting = 0;
            hideTimer = 0;
        }
    }

    // start looping game sound if Gollum has said "preciousss"
    if (timeCount == 100 && justPlayed) {
        playSoundA(lotr, LOTRLEN, LOTRFREQ, 1);
        justPlayed = 0;
    }

    // if start button is pressed, go to pause
    if (BUTTON_PRESSED(BUTTON_START))  {
        pauseSound();
        goToPause();
    }

    // if the end of the level is reached, go to mini game
    if (fin == 1) {
        goToMiniGame();
        initGame2();
    }

    // if button A is pressed, swing sword (attack enemies)
    if (BUTTON_PRESSED(BUTTON_A)) {
        swing = 1;
    }

    // if button B is pressed, player is hidden by the ring
    if (BUTTON_PRESSED(BUTTON_B)) {
        hidden = 1;
        startCounting = 1;
    }

    // if Select button is pressed increase cheatCount
    if (BUTTON_PRESSED(BUTTON_SELECT)) {
        if (cheatCount < 3) {
            cheatCount++;
        }
    }

    // if player runs out of lives, game over
    if (pLives == 0) {
        goToLose();
    }
}

// Sets up mini game state
void goToMiniGame() {

    // makes note that mini game is the current state for refrence in pause state
    beforePause = 1;

    // sets up display control register
    REG_DISPCTL = MODE0 | BG3_ENABLE | SPRITE_ENABLE | BG2_ENABLE;

    // loads lava tile palette
    DMANow(3, lavaPal, PALETTE, 256);

    // sets up control register for background 3
    REG_BG3CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(29) | BG_SIZE_SMALL;

    // loads lava tiles into charblock 0
    DMANow(3, lavaTiles, &CHARBLOCK[0], lavaTilesLen/2);

    // loads lava map into screenblock
    DMANow(3, lavaMap, &SCREENBLOCK[29], lavaMapLen/2);

    // sets up control register for background 2
    REG_BG2CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;

    // loads lavaG (ground) tiles into charblock 1
    DMANow(3, lavaGTiles, &CHARBLOCK[1], lavaGTilesLen / 2);

    // loads lavaG map into screenblock
    DMANow(3, lavaGMap, &SCREENBLOCK[31],lavaGMapLen/2);

    hOff = 0;
    buttons = BUTTONS;

    // Sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen/2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen/2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128*4);

    //sets state to MINIGAME
    state = MINIGAME;
}

// Runs every frame of the mini game state
void miniGame() {
    
    updateGame2();
    waitForVBlank();
    drawGame2();

    // if start button is pressed, go to pause
    if (BUTTON_PRESSED(BUTTON_START)) 
        goToPause();

    // if Select button is pressed increase cheatCount
    if (BUTTON_PRESSED(BUTTON_SELECT)) {
        if (cheatCount < 3) {
            cheatCount++;
        }
    }

    // if player runs out of lives, game over
    if (playerLives == 0) {
        goToLose();
    }

    // once player has gone a certain distance in the mini game, go to level 2
    if (distTraveled > 900) {
        goToLevel2();
        initGame3();
    }
}

// Sets up the level2 state
void goToLevel2() {

    // lvl2 background
    DMANow(3, lvl2Pal, PALETTE, 256);
    DMANow(3, lvl2Tiles, &CHARBLOCK[0], lvl1TilesLen/2);
    DMANow(3, lvl2Map, &SCREENBLOCK[28], lvl1MapLen/2);
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(28) | BG_SIZE_LARGE;


    // sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen/2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen/2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128*4);

    // enables mode, background, and sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;

    //sets state to LEVEL2
    state = LEVEL2;

    // makes note that level 2 is the current state for refrence in pause state
    beforePause = 2;
    timeCount2 = 0;
    soundLen = 0;
}

// Runs every frame of the level2 state
void level2() {

    timeCount2++;
    soundLen++;
    buttons = BUTTONS;
    updateGame3();
    drawGame3();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128*4);

    if (timeCount2 % 500 == 0) {
        // plays non looping sound of Gollum saying "preciousss" to start
        playSoundB(precious, PRECIOUSLEN, PRECIOUSFREQ, 0);
    } 

    if (startCounting == 1) {
        hideTimer++;
        if (hideTimer > 200) {
            hidden = 0;
            startCounting = 0;
            hideTimer = 0;
        }
    }

    // if start button is pressed, go to pause
    if (BUTTON_PRESSED(BUTTON_START)) 
        goToPause();

    // if button A is pressed, swing sword (attack enemies)
    if (BUTTON_PRESSED(BUTTON_A)) {
        swing2 = 1;
    }

    // if Select button is pressed increase cheatCount
    if (BUTTON_PRESSED(BUTTON_SELECT)) {
        if (cheatCount < 3) {
            cheatCount++;
        }
    }

     // if button B is pressed, player is hidden by the ring
    if (BUTTON_PRESSED(BUTTON_B)) {
        hidden = 1;
        startCounting = 1;
    }

    // if level complete, win the game
    if (fin == 1) {
        goToWin();
    }

    // if player is out of lives, game over
    if (pLives == 0) {
        goToLose();
    }
}

// Sets up pause state
void goToPause() {

    //enables background
    REG_DISPCTL = MODE0 | BG1_ENABLE | BG_SIZE_SMALL;  
    // loads pause tile palette
    DMANow(3, pausePal, PALETTE, 256);
    // loads pause tiles to charblock
    DMANow(3, pauseTiles, &CHARBLOCK[0], pauseTilesLen / 2);
    // loads pause map to screenblock
    DMANow(3, pauseMap, &SCREENBLOCK[31], pauseMapLen/2);

    // Sets state to PAUSE
    state = PAUSE;
}

// Runs every frame of pause state
void pause() {
    
    waitForVBlank();

    // if start button pressed...
    if (BUTTON_PRESSED(BUTTON_START)) {
        // if was in game state before pause, return to game
        if (beforePause == 0) {
            unpauseSound();
            goToGame();
        // if was in mini game state before pause, return to mini game
        } else if (beforePause == 1) {
            unpauseSound();
            goToMiniGame();
        // if was in level2 state before pause, return to level2
        } else {
            unpauseSound();
            goToLevel2();
        }
    }

    // if select button pressed, go to start
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}

// Sets up win state
void goToWin() {

    //enables background
    REG_DISPCTL = MODE0 | BG1_ENABLE;
    
    // loads win tile palette
    DMANow(3, winPal, PALETTE, 256);

    // loads win tiles to charblock
    DMANow(3, winTiles, &CHARBLOCK[0], winTilesLen / 2);

    // loads win map to screenblock
    DMANow(3, winMap, &SCREENBLOCK[31], winMapLen/2);

    //sets state to WIN
    state = WIN;
}

// every frame of the win state
void win() {

    waitForVBlank();

    // if start button pressed, go to start screen
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}

// Sets up lose state
void goToLose() {

    //enables background
    // enabling sprites because we want to hide them
    // while we're still in the game state, as the state is NOT yet lose
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;

    // loads lose tile palette
    DMANow(3, losePal, PALETTE, 256);

    // loads lose tiles to charblock
    DMANow(3, loseTiles, &CHARBLOCK[0], loseTilesLen / 2);

    // loads lose map to screenblock
    DMANow(3, loseMap, &SCREENBLOCK[31], loseMapLen/2);

    //sets state to LOSE
    state = LOSE;
}

// every frame of lose state
void lose() {

    // actually hide the sprites
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);

    // if start button pressed, go to start screen
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}