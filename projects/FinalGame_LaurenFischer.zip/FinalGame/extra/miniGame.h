// Constants
#define MAPHEIGHT2 160
#define MAPWIDTH2 480

// Variables
extern int hOff;
extern int vOff;
extern OBJ_ATTR shadowOAM[128];
extern ANISPRITE pikachu;


// Prototypes
void initGame2();
void updateGame2();
void drawGame2();
void initPlayer2();
void updatePlayer2();
void animatePlayer2();
void drawPlayer2();

// Enemy Struct
typedef struct {
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
	int width;
    int height;
    int type;
	int active;
	int cdel;
	int index;
	int aniState;
} ENEMY2;

typedef struct {
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int rdel;
    int cdel;
    int width;
    int height;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
    int hide;
} SPRITE;
// typedef struct {
//     int screenRow;
//     int screenCol;
//     int worldRow;
//     int worldCol;
//     int rdel;
//     int cdel;
//     int width;
//     int height;
//     int aniCounter;
//     int aniState;
//     int prevAniState;
//     int curFrame;
//     int numFrames;
//     int hide;
// } ANISPRITE;