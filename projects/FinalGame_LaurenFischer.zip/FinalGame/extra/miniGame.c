#include "myLib.h"
#include "miniGame.h"
#include "collisionmap.h"

// Variables
int hOff;
// int vOff;
int movementTimer;
int movementTimerLimit;
OBJ_ATTR shadowOAM[128];
SPRITE player;
ENEMY2 eye;

// player animation states for aniState
enum {RIGHT, LEFT, IDLE};

// Initialize the game
void initGame2() {

	// Place screen on map
    // vOff = 80;
    hOff = 9;
    movementTimer = 0;
	movementTimerLimit = 5;

    initEnemy();
    initPlayer2();
}

// Updates the game each frame
void updateGame2() {
    
	updatePlayer2();
    // for (int i = 0; i < ENEMYCOUNT; i++)
		updateEnemy();
}

// Draws the game each frame
void drawGame2() {

    drawPlayer2();
    drawEnemy();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128*4);

    REG_BG0HOFF = hOff;
    // REG_BG0VOFF = vOff;
}

// Initialize the player
void initPlayer2() {

    player.width = 16;
    player.height = 16;
    player.rdel = 1;
    player.cdel = 1;

    // Place in the middle of the screen in the world location chosen earlier
    player.worldRow = 90;
    player.worldCol = 20;
    player.aniCounter = 0;
    player.curFrame = 0;
    player.numFrames = 3;
    player.aniState = RIGHT;
}

// Handle every-frame actions of the player
void updatePlayer2() {

    if(BUTTON_HELD(BUTTON_LEFT)) {
        if (player.worldCol > 0) {

            // Update player's world position if the above is true
            player.worldCol -= player.cdel;



            if ( player.screenCol < SCREENWIDTH/2 && hOff > 0) {
                // Update background offset variable if the above is true
                hOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_RIGHT)) {
        if (player.worldCol + player.width - 1 < MAPWIDTH2) {

            // Update player's world position if the above is true
            player.worldCol += player.cdel;



            if ( player.screenCol + player.width - 1 > SCREENWIDTH/2  && player.worldCol + SCREENWIDTH - player.screenCol < MAPWIDTH2) {
                // Update background offset variable if the above is true
                hOff++;
            }
        }
    }

    // TODO 1.0: Update screen row and screen col
    // player.screenRow = player.worldRow - vOff;
    player.screenCol = player.worldCol - hOff;


    animatePlayer2();
}

// Handle player animation states
void animatePlayer2() {

    // Set previous state to current state
    player.prevAniState = player.aniState;
    player.aniState = IDLE;

    // Change the animation frame every 20 frames of gameplay
    if(player.aniCounter % 20 == 0) {
        player.curFrame = (player.curFrame + 1) % player.numFrames;
    }

    // Control movement and change animation state
    if(BUTTON_HELD(BUTTON_LEFT))
        player.aniState = LEFT;
    if(BUTTON_HELD(BUTTON_RIGHT))
        player.aniState = RIGHT;

    // If the player aniState is idle, frame is player standing
    if (player.aniState == IDLE) {
        player.curFrame = 0;
        player.aniCounter = 0;
        player.aniState = player.prevAniState;
    } else {
        player.aniCounter++;
    }

    movementTimer++;
}

// Draw the player
void drawPlayer2() {

    if (player.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(player.aniState * 2, player.curFrame * 2);
    }
}

void drawEnemy() {
		if (eye.active) {
			shadowOAM[1].attr0 = eye.worldRow | ATTR0_4BPP | ATTR0_WIDE;
			shadowOAM[1].attr1 = eye.worldCol | ATTR1_MEDIUM;
			shadowOAM[1].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(10,0);
        }
}

void initEnemy() {
		eye.width = 16;
		eye.height = 16;
		eye.type = 0;
		eye.active = 1;
		eye.cdel = 1;
		eye.index = 1;
		eye.aniState = 0;
        eye.worldRow = 20;
        eye.worldCol = 20;
}

void updateEnemy() {
	// Checks enemy-player collision
	// if (e->active && collision(e->col, e->row, e->width, e->height,
	// 		spaceShip.col, spaceShip.row, spaceShip.width, spaceShip.height)) {
	// 			playerHit = 1;
	// 		}
	// if the movement timer goes off, move the enemies
	if (movementTimer > movementTimerLimit) {
		// for (int i = 0; i < ENEMYCOUNT; i++) {
            if (eye.cdel > 0) {
                if (eye.worldCol + eye.width - 1 < MAPWIDTH2) {
                 eye.worldCol += eye.cdel;
                } else {
                    eye.cdel = -eye.cdel;
                    eye.worldCol += eye.cdel;
                }
            } else {
                if (eye.worldCol > 0) {
                      eye.worldCol += eye.cdel;
                } else {
                    eye.cdel = -eye.cdel;
                    eye.worldCol += eye.cdel;
                }
            }
            // eye.worldCol += eye.cdel;
		}
		movementTimer = 0;
	// }
}