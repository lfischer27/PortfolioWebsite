// Constants
#define MAPHEIGHT 300
#define MAPWIDTH 300
#define ENEMYCOUNT2 3

// Variables
extern int hOff;
extern int vOff;
extern OBJ_ATTR shadowOAM[128];
extern ANISPRITE player;
extern int pLives;
extern int fin;
extern int swing2;


// Function Declarations
void initGame3();
void updateGame3();
void drawGame3();
void initPlayer3();
void updatePlayer3();
void animatePlayer3();
void drawPlayer3();
void updateEnemies3();
void initEnemies3();
void drawEnemies3();

// Enemy Struct
typedef struct {
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
	int width;
    int height;
    int type;
	int active;
	int cdel;
    int rdel;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
} ENEMY3;
