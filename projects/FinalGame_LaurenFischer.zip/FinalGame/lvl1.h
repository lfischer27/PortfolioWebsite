
//{{BLOCK(lvl1)

//======================================================================
//
//	lvl1, 512x512@4, 
//	+ palette 256 entries, not compressed
//	+ 943 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x64 
//	Total size: 512 + 30176 + 8192 = 38880
//
//	Time-stamp: 2019-11-19, 16:42:41
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LVL1_H
#define GRIT_LVL1_H

#define lvl1TilesLen 30176
extern const unsigned short lvl1Tiles[15088];

#define lvl1MapLen 8192
extern const unsigned short lvl1Map[4096];

#define lvl1PalLen 512
extern const unsigned short lvl1Pal[256];

#endif // GRIT_LVL1_H

//}}BLOCK(lvl1)
