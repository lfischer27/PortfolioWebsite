// Constants
#define MAPHEIGHT 300
#define MAPWIDTH 300
#define ENEMYCOUNT 2

// Variables
extern int hOff;
extern int vOff;
extern OBJ_ATTR shadowOAM[128];
extern ANISPRITE player;
extern int pLives;
extern int fin;
extern int swing;
extern int hidden;

// Function Declarations
void initGame();
void updateGame();
void drawGame();
void initPlayer();
void updatePlayer();
void animatePlayer();
void drawPlayer();
void updateEnemies();
void initEnemies();
void drawEnemies();

// Enemy Struct
typedef struct {
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
	int width;
    int height;
    int type;
	int active;
	int cdel;
    int rdel;
	int index;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
    int lives;
    int higher;
} ENEMY;
