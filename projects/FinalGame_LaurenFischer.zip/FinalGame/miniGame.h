// Constants
#define MAPHEIGHT2 160
#define MAPWIDTH2 480
#define ROCKCOUNT 3

// Variables
extern int hOff;
extern int vOff;
extern OBJ_ATTR shadowOAM[128];
extern int playerLives;
extern int distTraveled;

// Prototypes
void initGame2();
void updateGame2();
void drawGame2();
void initPlayer2();
void updatePlayer2();
void animatePlayer2();
void drawPlayer2();
void initEnemy();
void initRocks();
void drawRocks();
void drawEnemy();
void updateEnemy();
void updateRocks();

typedef struct {
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int rdel;
    int cdel;
    int width;
    int height;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
    int hide;
} SPRITE;

// Enemy Struct
typedef struct {
    int row;
    int col;
	int width;
    int height;
	int active;
	int cdel;
	int index;
	int aniState;
} ENEMYTWO;

// Rock Struct
typedef struct {
    int row;
    int col;
	int width;
    int height;
} ROCK;