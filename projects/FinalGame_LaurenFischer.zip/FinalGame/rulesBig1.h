
//{{BLOCK(rulesBig1)

//======================================================================
//
//	rulesBig1, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 249 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 32 + 7968 + 2048 = 10048
//
//	Time-stamp: 2019-11-25, 17:00:47
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_RULESBIG1_H
#define GRIT_RULESBIG1_H

#define rulesBig1TilesLen 7968
extern const unsigned short rulesBig1Tiles[3984];

#define rulesBig1MapLen 2048
extern const unsigned short rulesBig1Map[1024];

#define rulesBig1PalLen 32
extern const unsigned short rulesBig1Pal[16];

#endif // GRIT_RULESBIG1_H

//}}BLOCK(rulesBig1)
