#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "space.h"
#include "pause.h"
#include "spaceBG.h"
#include "lose.h"
#include "spriteSheet2.h"
#include "win.h"
#include "game.h"

void initialize();

// State Functions
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();

// States
enum {START, GAME, PAUSE, WIN, LOSE};
int state;

// Random Seed
int seed;

unsigned short buttons;
unsigned short oldButtons;

OBJ_ATTR shadowOAM[128];


int main() {

    initialize(); 

	while(1) {

		oldButtons = buttons;
        buttons = BUTTONS;

		// State Machine
        switch(state) {

            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
        }
	}
}


void initialize() {

    // Enables mode, background, and sprites
	REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;

    // Hides all sprites
	hideSprites();

    // Go to set up for start screen
    goToStart();

}

// Sets up the start state
void goToStart() {

    // loads space tile palette
    DMANow(3, spacePal, PALETTE, 256);

    // loads background
	REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;

	// loads space tiles to charblock
    DMANow(3, spaceTiles, &CHARBLOCK[0], spaceTilesLen / 2);

    // loads space map to screenblock
    DMANow(3, spaceMap, &SCREENBLOCK[31], spaceMapLen/2);

    // updates state
    state = START;

    // seed randomization
    seed = 0;
}

// every frame of start state
void start() {

    seed++;

    waitForVBlank();

    // if start button pressed, start game
    if (BUTTON_PRESSED(BUTTON_START)) {

		DMANow(3, pausePal, PALETTE, 256);

        // Seed the random generator
        srand(seed);

        goToGame();
        initGame();
    }
}

// Sets up the game state
void goToGame() {

    // loads background
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;  

    // loads spaceBG tile palette
    DMANow(3, spaceBGPal, PALETTE, 256);
	// loads spaceBG tiles to charblock
    DMANow(3, spaceBGTiles, &CHARBLOCK[0], spaceBGTilesLen / 2);
    // loads spaceBG map to screenblock
    DMANow(3, spaceBGMap, &SCREENBLOCK[31], spaceBGMapLen/2);

    //updates state
    state = GAME;
}

// every frame of game state
void game() {

    buttons = BUTTONS;
    updateGame();
    waitForVBlank();
    drawGame();

    // if start button is pressed, go to pause
    if (BUTTON_PRESSED(BUTTON_START)) 
        goToPause();
    // if no more enemies, win game
    else if (enemiesRemaining == 0)
        goToWin();
    // if player loses all thier lives, lose game
    else if (playerLives == 0 || playerHit == 1)
        goToLose();
}

// Sets up the pause state
void goToPause() {
    //enables background without enabling sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE;  
    // loads pause tile palette
    DMANow(3, pausePal, PALETTE, 256);
    // loads pause tiles to charblock
    DMANow(3, pauseTiles, &CHARBLOCK[0], pauseTilesLen / 2);
    // loads pause map to screenblock
    DMANow(3, pauseMap, &SCREENBLOCK[31], pauseMapLen/2);

    //updates state
    state = PAUSE;
}

// Runs every frame of pause state
void pause() {
    
    waitForVBlank();

    // if start button pressed, return to game
    if (BUTTON_PRESSED(BUTTON_START))
        goToGame();
    //if select button pressed, go to start game
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}

// Sets up the win state
void goToWin() {
    //enables background without enabling sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE;
    // loads win tile palette
    DMANow(3, winPal, PALETTE, 256);
    // loads pause tiles to charblock
    DMANow(3, winTiles, &CHARBLOCK[0], winTilesLen / 2);
    // loads pause map to screenblock
    DMANow(3, winMap, &SCREENBLOCK[31], winMapLen/2);

    //updates state
    state = WIN;
}

// every frame of the win state
void win() {

    waitForVBlank();

    // if start button pressed, go to start screen
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}

// Sets up lose state
void goToLose() {
    //enables background without enabling sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE;
    // loads lose tile palette
    DMANow(3, losePal, PALETTE, 256);
    // loads lose tiles to charblock
    DMANow(3, loseTiles, &CHARBLOCK[0], loseTilesLen / 2);
    // loads lose map to screenblock
    DMANow(3, loseMap, &SCREENBLOCK[31], loseMapLen/2);

    //updates state
    state = LOSE;
}

// every frame of lose state
void lose() {

    waitForVBlank();

    // if start button pressed, go to start screen
    if (BUTTON_PRESSED(BUTTON_START)) 
        goToStart();
}