
//{{BLOCK(ship)

//======================================================================
//
//	ship, 32x32@4, 
//	+ palette 256 entries, not compressed
//	+ 7 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 4x4 
//	Total size: 512 + 224 + 32 = 768
//
//	Time-stamp: 2019-10-24, 11:14:22
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SHIP_H
#define GRIT_SHIP_H

#define shipTilesLen 224
extern const unsigned short shipTiles[112];

#define shipMapLen 32
extern const unsigned short shipMap[16];

#define shipPalLen 512
extern const unsigned short shipPal[256];

#endif // GRIT_SHIP_H

//}}BLOCK(ship)
