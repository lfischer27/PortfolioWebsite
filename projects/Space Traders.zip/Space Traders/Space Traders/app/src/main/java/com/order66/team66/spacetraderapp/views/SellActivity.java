package com.order66.team66.spacetraderapp.views;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.order66.team66.spacetraderapp.R;

public class SellActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
    }
}
