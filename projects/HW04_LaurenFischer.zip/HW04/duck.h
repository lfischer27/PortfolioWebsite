
//{{BLOCK(duck)

//======================================================================
//
//	duck, 8x9@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 72 = 584
//
//	Time-stamp: 2019-10-08, 18:36:52
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_DUCK_H
#define GRIT_DUCK_H

#define duckBitmapLen 72
extern const unsigned short duckBitmap[36];

#define duckPalLen 512
extern const unsigned short duckPal[256];

#endif // GRIT_DUCK_H

//}}BLOCK(duck)
