#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "text.h"
#include "game.h"
#include "Orchard.h"

// function declarations
void initialize();
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();

// states
int gameState;
enum {START, GAME, PAUSE, WIN};

// variables
unsigned short buttons;
unsigned short oldButtons;
int seed;
char text[41];

int main() {

    initialize();

    while(1) {

        // updates buttons
        oldButtons = buttons;
        buttons = BUTTONS;

        // state machine
        switch(gameState) {
            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
        }

    }
}

// initialization
void initialize() {

    REG_DISPCTL = MODE4 | BG2_ENABLE | DISP_BACKBUFFER;
    goToStart();

}

// one time start state
void goToStart() {

    //loads orchard palette and draws orchard
    DMANow(3, OrchardPal, PALETTE, OrchardPalLen);
    drawFullscreenImage4(OrchardBitmap);

    waitForVBlank();
    flipPage();

    gameState = START;
    seed = 0;
}

// every frame start state
void start() {

    seed++;
    waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_START)) {
        srand(seed);
        goToGame();
        initGame();
    }
}

// one time game state
void goToGame() {

    gameState = GAME;

}

// every frame game state
void game() {

    updateGame();
    drawGame();

    // draws score
    sprintf(text, "Fruit Sorted: %d", fruitSorted);
    drawString4(2, 3, text, WHITEID);

    waitForVBlank();
    flipPage();

    // switches to pause screen if start is pressed
    if (BUTTON_PRESSED(BUTTON_START))
        goToPause();
    //switches to win if enough fruit is collected
    else if (fruitSorted == 5)
        goToWin();
}

// one time pause state
void goToPause() {

    fillScreen4(GRAYID);
    drawString4(105, 77, "Pause", BLACKID);
    waitForVBlank();
    flipPage();
    gameState = PAUSE;
}

// every frame pause state
void pause() {

    waitForVBlank();
    //starts game if start is pressed
    if (BUTTON_PRESSED(BUTTON_START))
        goToGame();
    //goes back to main/start screen if select button is pressed
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}

// one time win state
void goToWin() {

    fillScreen4(GREENID);
    drawString4(95, 70, "You Win!", BLACKID);
    waitForVBlank();
    flipPage();
    gameState = WIN;
}

// every frame win state
void win() {

    waitForVBlank();
    // goes to main/start screen if select button is pressed
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}