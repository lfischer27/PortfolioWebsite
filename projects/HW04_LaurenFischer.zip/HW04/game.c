#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "ducky.h"
#include "text.h"


// variables
PLAYER player;
APPLE apples[APPLECOUNT];
ORNGE oranges[ORANGECOUNT];
int fruitSorted;

// initialization
void initGame() {

	initPlayer();
    initApples();
	initOranges();

	fruitSorted = 0;
    unsigned short colors[NUMCOLORS] = {BLACK, BLUE, GREEN, RED, WHITE, GRAY, ORANGE};

    //loads in duck(y) image palette
	DMANow(3, duckyPal, PALETTE, duckyPalLen);

    // puts colors into palette
    for (int i = 0; i < NUMCOLORS; i++) {
        PALETTE[256-NUMCOLORS+i] = colors[i];
    }
}

// updates game
void updateGame() {

	updatePlayer();

	// updates all apples
	for (int i = 0; i < APPLECOUNT; i++)
		updateApple(&apples[i]);

	// updates all oranges
	for (int i = 0; i < ORANGECOUNT; i++)
		updateOrange(&oranges[i]);
}

// draws game
void drawGame() {

    fillScreen4(BLACKID);
	drawPlayer();
	drawGround();
	drawABin();
	drawOBin();

	// draws apples
	for (int i = 0; i < APPLECOUNT; i++)
		drawApple(&apples[i]);

	// draws oranges
	for (int i = 0; i < ORANGECOUNT; i++)
		drawOrange(&oranges[i]);
}

// draws ground/grass
void drawGround() {
	drawRect4(0, 154, 240, 6, GREENID);
}
// draws apple bin
void drawABin() {
	drawRect4(0, 140, 18, 14, GRAYID);
	drawChar4(5, 144, 'A', WHITEID);
}
// draws orange bin
void drawOBin() {
	drawRect4(222, 140, 18, 14, GRAYID);
	drawChar4(228, 144, 'O', WHITEID);
}

// initializes player
void initPlayer() {

	player.col = 118;
	player.row = 136;
	player.cdel = 2;
	player.width = 16;
	player.height = 18;
	player.color = GREENID;
	player.holding = 0;
	player.appleTimer = 20;
	player.orangeTimer = 20;
	player.appleTimerLimit = rand()%100+70;
	player.orangeTimerLimit = rand()%100+70;
}

// updates player
void updatePlayer() {

		// moves player left if left button is pressed
	if (BUTTON_HELD(BUTTON_LEFT) && player.col >0) {

		player.col -= player.cdel;

	// moves player right if right button is pressed
	} else if (BUTTON_HELD(BUTTON_RIGHT) && (player.col + player.width) < SCREENWIDTH) {

		player.col += player.cdel;
	}

	//drops apples
	if (player.appleTimer >= player.appleTimerLimit) {
		spawnApple();
		player.appleTimer = 0;
		player.appleTimerLimit = rand() % 100 + 30;
	}

	//drops oranges
	if (player.orangeTimer >= player.orangeTimerLimit) {
		spawnOrange();
		player.orangeTimer = 0;
		player.orangeTimerLimit = rand() % 100 + 30;
	}

	player.orangeTimer++;
	player.appleTimer++;
}

// draws player
void drawPlayer() {

	drawImage4(player.col, player.row, player.width, player.height, duckyBitmap);
}

// initializes apples
void initApples() {

	for (int i = 0; i < APPLECOUNT; i++) {

		apples[i].height = 5;
		apples[i].width = 5;
		apples[i].row = 15;
		apples[i].col = rand() % 130 + 10;
		apples[i].rdel = 2;
		apples[i].active = 0;
		apples[i].caught = 0;
	}
}

// initializes oranges
void initOranges() {

	for (int i = 0; i < ORANGECOUNT; i++) {

		oranges[i].height = 5;
		oranges[i].width = 5;
		oranges[i].row = 15;
		oranges[i].col = rand() % 130 + 10;
		oranges[i].rdel = 2;
		oranges[i].active = 0;
		oranges[i].caught = 0;
	}
}

// updates apple
void updateApple(APPLE* a) {

	if (a->active) {

		//causes apple to become inactive if it hits the ground
		if (a->row + a->height >= 154) {
			a->active = 0;
		}

		// if the player if not holding anything and an uncaught apple collides with player, apple is caught and player holds it
		if (a->active && player.holding == 0 && a->caught == 0 && collision(a->col, a->row, a->width, a->height, player.col, player.row, player.width, player.height)) {
			a->caught = 1;
			player.holding = 1;
		}

		// apple falls normally if not caught, follows player if caught
		if (a->caught == 0) {
			a->row += a->rdel;
		} else {
			a->row = player.row - a->height;
			a->col = player.col + 6;
		}

		// if the player drops an apple in the apple bin, apple is made inactive and score increases
		if (a->active && BUTTON_PRESSED(BUTTON_A) && player.holding == 1 && a->caught == 1 && collision(0, 140,  18, 14, player.col, player.row, player.width, player.height)) {
				a->active = 0;
				a->caught = 0;
				a->row = 0;
				a->col = 0;
				player.holding = 0;
				fruitSorted++;
		}

		// if the player drops an apple in the orange bin, apple is made inactive and score decreases
		if (a->active && BUTTON_PRESSED(BUTTON_A) && player.holding == 1 && a->caught == 1 && collision(222, 140, 18, 14, player.col, player.row, player.width, player.height)) {
				a->active = 0;
				a->caught = 0;
				a->row = 0;
				a->col = 0;
				player.holding = 0;
				fruitSorted--;
		}
	}
}

// updates orange
void updateOrange(ORNGE* o) {

	//causes orange to become inactive if it hits the ground
	if (o->active) {
		if (o->row + o->height >= 154) {
			o->active = 0;
		}

		// if the player if not holding anything and an uncaught orange collides with player, orange is caught and player holds it
		if (o->active && player.holding == 0 && o->caught == 0 && collision(o->col, o->row, o->width, o->height, player.col, player.row, player.width, player.height)) {
			o->caught = 1;
			player.holding = 1;
		}

		// orange falls normally if not caught, follows player if caught
		if (o->caught == 0) {
			o->row += o->rdel;
		} else {
			o->row = player.row - o->height;
			o->col = player.col + 6;
		}

		// if the player drops an orange in the orange bin, apple is made inactive and score increases
		if (o->active && BUTTON_PRESSED(BUTTON_A) && player.holding == 1 && o->caught == 1 && collision(222, 140, 18, 14, player.col, player.row, player.width, player.height)) {
				o->active = 0;
				o->caught = 0;
				o->row = 0;
				o->col = 0;
				player.holding = 0;
				fruitSorted++;
		}

		// if the player drops an orange in the apple bin, apple is made inactive and score decreases
		if (o->active && BUTTON_PRESSED(BUTTON_A) && player.holding == 1 && o->caught == 1 && collision(0, 140,  18, 14, player.col, player.row, player.width, player.height)) {
				o->active = 0;
				o->caught = 0;
				o->row = 0;
				o->col = 0;
				player.holding = 0;
				fruitSorted--;
		}
	}
}

// spawns apple
void spawnApple() {
	// activates first inactive apple from the pool
	for (int i = 0; i < APPLECOUNT; i++) {
		if (apples[i].active == 0) {
			apples[i].row = 15;
			apples[i].col = rand() % 200 + 20;
			apples[i].caught = 0;
			apples[i].active = 1;
			break;
		}
	}

}

// spawns orange
void spawnOrange() {
	// activates first inactive orange from the pool
	for (int i = 0; i < ORANGECOUNT; i++) {
		if (oranges[i].active == 0) {
			oranges[i].row = 15;
			oranges[i].col = rand() % 200 + 20;
			oranges[i].caught = 0;
			oranges[i].active = 1;
			break;
		}
	}

}

// draws apple
void drawApple(APPLE* a) {
	if (a-> active) {
			drawRect4(a->col, a->row, a->width, a->height, REDID);
			setPixel4(a->col + a->width/2, a->row - 1, GREENID);
	}
}

// draws orange
void drawOrange(ORNGE* b) {
		if (b-> active) {
			drawRect4(b->col, b->row, b->width, b->height, ORANGEID);
			setPixel4(b->col + b->width/2, b->row, GREENID);
		}
}