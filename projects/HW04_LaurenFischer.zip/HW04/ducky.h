
//{{BLOCK(ducky)

//======================================================================
//
//	ducky, 16x18@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 288 = 800
//
//	Time-stamp: 2019-10-08, 18:47:43
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_DUCKY_H
#define GRIT_DUCKY_H

#define duckyBitmapLen 288
extern const unsigned short duckyBitmap[144];

#define duckyPalLen 512
extern const unsigned short duckyPal[256];

#endif // GRIT_DUCKY_H

//}}BLOCK(ducky)
