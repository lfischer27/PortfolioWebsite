// player struct
typedef struct {
	int row;
	int col;
	int cdel;
	int height;
	int width;
	unsigned char color;
	int holding;
	int appleTimer;
	int appleTimerLimit;
	int orangeTimer;
	int orangeTimerLimit;
} PLAYER;

// apple struct
typedef struct {
	int row;
	int col;
	int rdel;
	int height;
	int width;
	int active;
	int caught;
} APPLE;

// orange struct
typedef struct {
	int row;
	int col;
	int rdel;
	int height;
	int width;
	int active;
	int caught;
} ORNGE;

// constants
#define APPLECOUNT 6
#define ORANGECOUNT 6
#define NUMCOLORS 7

// variables
extern PLAYER player;
extern APPLE apples[APPLECOUNT];
extern ORNGE oranges[ORANGECOUNT];

extern int fruitSorted;

//sets up color palette
enum {BLACKID=(256-NUMCOLORS), BLUEID, GREENID, REDID, WHITEID, GRAYID, ORANGEID};
extern unsigned short colors[NUMCOLORS];

// function declarations
void initGame();
void updateGame();
void drawGame();
void drawGround();
void drawABin();
void drawOBin();
void initPlayer();
void updatePlayer();
void drawPlayer();
void initApples();
void spawnApple();
void updateApple(APPLE *);
void drawApple(APPLE *);
void initOranges();
void spawnOrange();
void updateOrange(ORNGE *);
void drawOrange(ORNGE *);