Press Start on the Orchard screen to begin the game
use left and right arrow keys to move the duck/player
catch the falling fruit (you can only hold 1 piece at a time) by colliding with a piece of falling fruit
once you've caught a piece of fruit, put it in its respective bin
	-press button A while touching a bin to drop the fruit in
	-Apple bin has an 'A' on it
	-Orange bin has an 'O' on it
if you put fruit in the wrong bin, your fruit sorted score goes down
if you sort the fruit properly, your score goes up
if the fruit sorted score reaches 5, you win!